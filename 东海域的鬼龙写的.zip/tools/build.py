#!/usr/bin/env python3
"""Build the static site from templates + data, once per language.

    python tools/build.py            # -> site/  (4 languages, 40 pages)
    python tools/build.py --check    # build, then run the validation pass

Pipeline:  data/*.json + templates/*  ->  site/**/*.html (+ assets, data copies)

Layout: the default locale lives at the site root, every other locale gets its
own directory (site/en/, site/ja/, site/zh-Hant/), and the header/footer switch
between them with ordinary links, so the whole thing works without JavaScript.

The template language is deliberately tiny:
    {{ include:partials/x.html }}   inline another template
    {{{ raw }}}                     insert pre-rendered HTML
    {{ value }}                     insert an HTML-escaped value
"""

from __future__ import annotations

import argparse
import html
import json
import re
import shutil
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
TEMPLATES = ROOT / "templates"
ASSETS = ROOT / "assets"
SITE = ROOT / "site"

INCLUDE = re.compile(r"\{\{\s*include:([\w./-]+)\s*\}\}")
RAW_VAR = re.compile(r"\{\{\{\s*(\w+)\s*\}\}\}")
ESC_VAR = re.compile(r"\{\{\s*(\w+)\s*\}\}")

MONTH_ABBR = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


# --------------------------------------------------------------------- templating


class MissingKey(KeyError):
    pass


def render(text: str, ctx: dict[str, Any]) -> str:
    def do_include(match: re.Match[str]) -> str:
        target = TEMPLATES / match.group(1)
        if not target.is_file():
            raise MissingKey(f"include not found: {match.group(1)}")
        return render(target.read_text(encoding="utf-8"), ctx)

    text = INCLUDE.sub(do_include, text)

    def do_raw(match: re.Match[str]) -> str:
        key = match.group(1)
        if key not in ctx:
            raise MissingKey(f"raw placeholder {{{{{key}}}}} has no value")
        return str(ctx[key])

    text = RAW_VAR.sub(do_raw, text)

    def do_esc(match: re.Match[str]) -> str:
        key = match.group(1)
        if key not in ctx:
            raise MissingKey(f"placeholder {{{{{key}}}}} has no value")
        return html.escape(str(ctx[key]), quote=True)

    return ESC_VAR.sub(do_esc, text)


def render_file(relative: str, ctx: dict[str, Any]) -> str:
    return render((TEMPLATES / relative).read_text(encoding="utf-8"), ctx)


_cache: dict[str, Any] = {}


def load(name: str) -> Any:
    if name not in _cache:
        _cache[name] = json.loads((DATA / f"{name}.json").read_text(encoding="utf-8"))
    return _cache[name]


# --------------------------------------------------------------------- site data


class Site:
    """Everything loaded once and shared by every locale."""

    def __init__(self) -> None:
        self.meta = load("site")
        self.creators = load("creators")
        self.thanks = load("thanks")
        self.birthdays = load("birthdays")
        self.toolbox = load("toolbox")
        self.avatar_map: dict[str, str] = load("avatars")["map"]
        self.modules: list[dict[str, Any]] = load("modules")["modules"]
        self.by_key = {m["key"]: m for m in self.modules}
        # Sub-pages (the toolbox tools) are reachable from their hub, not the nav.
        self.nav_modules = [m for m in self.modules if m.get("nav", True)]
        self.i18n = load("i18n")
        self.locales: list[dict[str, Any]] = self.i18n["locales"]
        self.strings: dict[str, dict[str, str]] = self.i18n["strings"]
        self.zodiac: dict[str, dict[str, str]] = self.i18n["zodiac"]
        self.default_locale: str = self.i18n["defaultLocale"]
        self.base_url: str = (self.meta.get("baseUrl") or "").rstrip("/")

    def locale(self, code: str) -> dict[str, Any]:
        for entry in self.locales:
            if entry["code"] == code:
                return entry
        raise MissingKey(f"unknown locale: {code}")


class PageBuilder:
    """Renders one page of one locale."""

    def __init__(self, site: Site, locale_code: str, module_key: str) -> None:
        self.site = site
        self.loc = site.locale(locale_code)
        self.code = locale_code
        self.module = site.by_key[module_key]
        self.key = module_key
        self.dir = self.loc["dir"]
        self.prefix = "../" if self.dir else ""

    # ---- strings & paths

    def t(self, key: str, **kwargs: Any) -> str:
        raw = self.site.strings[self.code].get(key)
        if raw is None:
            raise MissingKey(f"{self.code}: missing string {key!r}")
        return raw.format(**kwargs) if kwargs else raw

    def asset(self, relative: str) -> str:
        return self.prefix + relative

    def page_path(self, locale_code: str, module_key: str) -> str:
        """Site-root-relative path of a module page in another locale."""
        target = self.site.locale(locale_code)
        file = self.site.by_key[module_key]["file"]
        return f"{target['dir']}/{file}" if target["dir"] else file

    def url_for(self, locale_code: str, module_key: str) -> str:
        return self.prefix + self.page_path(locale_code, module_key)

    def absolute(self, path: str) -> str:
        """Absolute URL when a base URL is configured, page-relative otherwise."""
        return f"{self.site.base_url}/{path}" if self.site.base_url else self.prefix + path

    def t_context(self) -> dict[str, str]:
        """Every UI string of this locale, flattened for the template engine."""
        return {
            "t_" + key.replace(".", "_"): value
            for key, value in self.site.strings[self.code].items()
        }

    # ---- shared fragments

    def avatar(self, uid: str) -> str:
        return self.asset(self.site.avatar_map.get(uid, "assets/img/avatars/placeholder.svg"))

    def resolve_avatar(self, value: str) -> str:
        """An avatar may be a local path (archived/placeholder) or a remote URL."""
        value = (value or "").strip()
        if not value:
            return self.asset("assets/img/avatars/placeholder.svg")
        if value.startswith("http"):
            return value
        return self.asset(value)

    def person_avatar(self, person: dict[str, Any]) -> str:
        """Remote URL wins; otherwise trust the local avatar map.

        thanks.json records a bare `<uid>.webp` from the archive, but
        collect_assets may have produced a `.svg` placeholder instead, so the
        authoritative value for a local avatar is whatever data/avatars.json says.
        """
        raw = (person.get("avatar") or "").strip()
        if raw.startswith("http"):
            return raw
        mapped = self.site.avatar_map.get(person.get("uid") or "")
        return self.asset(mapped or raw or "assets/img/avatars/placeholder.svg")

    def person_card(self, person: dict[str, Any]) -> str:
        plays = person.get("plays")
        return render_file(
            "partials/person-card.html",
            {
                "uid": person["uid"],
                "name": person["name"],
                "avatar": self.person_avatar(person),
                "space": person.get("space") or f"https://space.bilibili.com/{person['uid']}",
                "openLabel": self.t("card.openSpace", name=person["name"]),
                "fansText": self.format_count(person.get("fans")),
                "followingText": self.format_count(person.get("following")),
                "playsText": self.format_count(plays) if plays is not None else "—",
                **self.t_context(),
            },
        )

    def creators_total(self) -> int:
        return int(self.site.creators.get("total") or self.site.creators.get("count") or 0)

    def format_count(self, value: int | None) -> str:
        """Abbreviate a number using the units the current language expects.

        Chinese and Japanese group by 万/亿(億); English groups by K/M/B.
        Keeping the raw integers in the data and formatting here is what lets
        one dataset render correctly in all four languages.
        """
        value = int(value or 0)
        if self.code == "en":
            for factor, suffix in ((1_000_000_000, "B"), (1_000_000, "M"), (1_000, "K")):
                if value >= factor:
                    return f"{value / factor:.1f}".rstrip("0").rstrip(".") + suffix
            return f"{value:,}"
        big, small = ("億", "万") if self.code == "ja" else ("亿", "万")
        if value >= 100_000_000:
            return f"{value / 100_000_000:.1f}".rstrip("0").rstrip(".") + big
        if value >= 10_000:
            return f"{value / 10_000:.1f}".rstrip("0").rstrip(".") + small
        return f"{value:,}"

    def head(self, subtitle: str, toolbar: str = "") -> dict[str, str]:
        head_key = self.module.get("headTitleKey")
        return {
            "icon": self.module["icon"],
            "accent": self.module["accent"],
            "title": self.t(head_key) if head_key else self.t(f"module.{self.key}.label"),
            "subtitle": subtitle,
            "toolbar": toolbar,
        }

    def nav_items(self, min_width: str) -> str:
        out = []
        for module in self.site.nav_modules:
            label = self.t(f"module.{module['key']}.label")
            classes = f"module-tab shrink-0 min-w-[{min_width}] text-center whitespace-nowrap"
            if module["key"] == self.key:
                classes += " module-tab--active"
            out.append(
                f'        <a class="{classes}" href="{self.url_for(self.code, module["key"])}"'
                + (' aria-current="page"' if module["key"] == self.key else "")
                + f">{html.escape(label)}</a>"
            )
        return "\n".join(out)

    def back_to_toolbox(self) -> str:
        return (
            '<a class="rank-chip" href="'
            + self.url_for(self.code, "toolbox")
            + f'">{html.escape(self.t("toolbox.back"))}</a>'
        )

    def lang_menu(self) -> str:
        items = []
        for entry in self.site.locales:
            url = self.url_for(entry["code"], self.key)
            current = entry["code"] == self.code
            items.append(
                f'    <li><a href="{url}" hreflang="{entry["code"]}" lang="{entry["htmlLang"]}"'
                + (' aria-current="true"' if current else "")
                + f'>{html.escape(entry["label"])}</a></li>'
            )
        return "\n".join(items)

    def footer_languages(self) -> str:
        parts = []
        for entry in self.site.locales:
            if entry["code"] == self.code:
                parts.append(
                    f'<span class="font-bold text-main-color" lang="{entry["htmlLang"]}">'
                    f'{html.escape(entry["label"])}</span>'
                )
            else:
                parts.append(
                    f'<a class="underline" href="{self.url_for(entry["code"], self.key)}"'
                    f' hreflang="{entry["code"]}" lang="{entry["htmlLang"]}">'
                    f'{html.escape(entry["label"])}</a>'
                )
        return "\n      ".join(parts)

    def alternates(self) -> str:
        lines = []
        for entry in self.site.locales:
            path = self.absolute(self.page_path(entry["code"], self.key))
            lines.append(f'  <link rel="alternate" hreflang="{entry["code"]}" href="{path}">')
        path = self.absolute(self.page_path(self.site.default_locale, self.key))
        lines.append(f'  <link rel="alternate" hreflang="x-default" href="{path}">')
        return "\n".join(lines)

    # ---- module bodies

    def body_card(self) -> str:
        cards = "\n".join(self.person_card(p) for p in self.site.creators["items"])
        subtitle = self.t(
            "card.count",
            n=self.site.creators["count"],
            total=self.creators_total(),
        )
        # The empty-state sentence wraps the live search term, so split on it.
        parts = self.t("card.empty", term="\x00").split("\x00")
        return render_file(
            "modules/card.html",
            {
                "cards": cards,
                "emptyPrefix": parts[0],
                "emptySuffix": parts[1] if len(parts) > 1 else "",
                **self.head(subtitle),
                **self.t_context(),
            },
        )

    def body_thanks(self) -> str:
        cards = "\n".join(self.person_card(p) for p in self.site.thanks["items"])
        subtitle = self.t("module.thanks.subtitle", n=self.site.thanks["count"])
        return render_file(
            "modules/thanks.html",
            {"cards": cards, **self.head(subtitle), **self.t_context()},
        )

    def body_ranking(self) -> str:
        items = [c for c in self.site.creators["items"] if (c.get("fans") or 0) > 0]
        ordered = sorted(items, key=lambda c: c.get("fans") or 0, reverse=True)
        top = ordered[0].get("fans") or 1
        rows = []
        for index, person in enumerate(ordered, start=1):
            width = max(2, round((person.get("fans") or 0) / top * 100))
            rows.append(
                f'            <li class="rank-row" data-uid="{person["uid"]}"'
                f' data-fans="{person.get("fans") or 0}"'
                f' data-following="{person.get("following") or 0}">\n'
                f'              <a class="rank-row__link" href="{person["space"]}" target="_blank" rel="noopener">\n'
                f'                <span class="rank-row__rank">{index}</span>\n'
                f'                <img class="rank-row__avatar" src="{self.person_avatar(person)}"'
                f' alt="{html.escape(person["name"], quote=True)}" loading="lazy">\n'
                f'                <span class="rank-row__name">{html.escape(person["name"])}</span>\n'
                f'                <span class="rank-row__bar"><i style="width: {width}%"></i></span>\n'
                f'                <span class="rank-row__value">{html.escape(self.format_count(person.get("fans")))}</span>\n'
                "              </a>\n"
                "            </li>"
            )
        return render_file(
            "modules/ranking.html",
            {
                "rows": "\n".join(rows),
                "top10": self.t("ranking.top", n=10),
                "top20": self.t("ranking.top", n=20),
                **self.head(self.t("ranking.subtitle", n=len(ordered))),
                **self.t_context(),
            },
        )

    def month_label(self, month_iso: str) -> str:
        year, month = month_iso.split("-")
        if self.code == "en":
            return f"{MONTH_ABBR[int(month)]} {year}"
        return f"{year}年{int(month)}月"

    def body_birthdays(self) -> str:
        data = self.site.birthdays
        weekdays = self.t("birthdays.weekdays").split(",")

        weekday_cells = "\n".join(
            f'              <div class="py-1 text-center font-bold text-xs text-subtle tracking-wide">{html.escape(d)}</div>'
            for d in weekdays
        )

        cells = []
        for day in data["days"]:
            classes = ["birthday-cell"]
            if day["weekend"]:
                classes.append("birthday-cell--weekend")
            if day["isToday"]:
                classes.append("birthday-cell--today")
            if day["people"]:
                classes.append("birthday-cell--active")

            stacks = "".join(
                f'<img src="{self.avatar(p["uid"])}" alt="{html.escape(p["name"], quote=True)}"'
                ' class="w-7 h-7 lg:w-8 lg:h-8 rounded-full border-2 border-white dark:border-slate-800 shadow-sm object-cover"'
                ' loading="lazy">'
                for p in day["people"]
            )
            if day["overflow"]:
                stacks += (
                    '<div class="w-7 h-7 lg:w-8 lg:h-8 rounded-full bg-slate-200 dark:bg-slate-700'
                    ' border-2 border-white dark:border-slate-800 flex items-center justify-center'
                    ' text-[9px] font-bold text-subtle">'
                    f'+{day["overflow"]}</div>'
                )

            stacks_block = (
                '<div class="flex-1 flex flex-col items-center justify-center min-h-0 pb-1">'
                f'<div class="avatar-stack -space-x-2">{stacks}</div></div>'
                if stacks
                else ""
            )
            title = self.t("birthdays.cellTitle", date=f'{data["month"]}-{day["day"]:02d}', n=day["total"])
            cells.append(
                f'              <div class="{" ".join(classes)}" title="{html.escape(title, quote=True)}">\n'
                '                <div class="flex justify-between items-start px-2 pt-1.5 relative z-10">\n'
                f'                  <span class="text-xs font-semibold font-mono leading-none transition-colors text-main-color">{day["day"]}</span>\n'
                "                </div>\n"
                f"                {stacks_block}\n"
                "              </div>"
            )

        today_items = "\n".join(
            f'''              <a class="flex items-center gap-3 bg-slate-100/80 dark:bg-slate-800/60 p-2 rounded-xl border border-transparent hover:border-rose-200 dark:hover:border-rose-500/30 hover:bg-rose-50/80 dark:hover:bg-slate-700/70 transition"
                 href="https://space.bilibili.com/{p["uid"]}" target="_blank" rel="noopener">
                <div class="relative">
                  <img src="{self.avatar(p["uid"])}" alt="{html.escape(p["name"], quote=True)}" loading="lazy"
                       class="w-10 h-10 rounded-full border border-subtle object-cover">
                  <div class="absolute -bottom-1 -right-1 text-xs" aria-hidden="true">🍰</div>
                </div>
                <div class="flex-1 min-w-0">
                  <div class="text-sm font-bold text-main-color truncate">{html.escape(p["name"])}</div>
                  <div class="text-xs text-rose-500 dark:text-rose-400 mt-0.5">{html.escape(self.t("birthdays.happy"))}</div>
                </div>
                <div class="text-subtle opacity-50" aria-hidden="true">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewbox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                </div>
              </a>'''
            for p in data["today"]
        )

        year, month = data["month"].split("-")
        return render_file(
            "modules/birthdays.html",
            {
                "icon": self.module["icon"],
                "accent": self.module["accent"],
                "title": self.t("module.birthdays.label"),
                "subtitle": self.month_label(data["month"]),
                "monthShort": f"{year}.{month}",
                "weekdayCells": weekday_cells,
                "dayCells": "\n".join(cells),
                "todayItems": today_items,
                **self.t_context(),
            },
        )

    def tool_by_key(self, tool_key: str) -> dict[str, Any]:
        for tool in self.site.toolbox["tools"]:
            if tool["key"] == tool_key:
                return tool
        raise MissingKey(f"toolbox.json has no tool {tool_key!r}")

    def body_toolbox(self) -> str:
        """The toolbox hub: one card per sub-tool."""
        cards = []
        for tool in self.site.toolbox["tools"]:
            module_key = f"toolbox-{tool['key']}"
            cards.append(
                render_file(
                    "partials/tool-card.html",
                    {
                        "href": self.url_for(self.code, module_key),
                        "accent": tool["accent"],
                        "icon": tool["icon"],
                        "name": self.t(f"module.{module_key}.label"),
                        "description": self.t(f"module.{module_key}.title").split(" - ", 1)[-1],
                        "count": tool["rowCount"],
                        "viewLabel": self.t("toolbox.view"),
                        "cta": self.site.by_key[module_key].get("cta", "#6366f1"),
                    },
                )
            )
        subtitle = self.t("toolbox.subtitle", n=self.site.toolbox["total"])
        return render_file(
            "modules/toolbox.html",
            {"cards": "\n".join(cards), **self.head(subtitle), **self.t_context()},
        )

    def body_tool(self) -> str:
        """One toolbox sub-tool: a ranked list, plus a link back to the hub."""
        tool = self.tool_by_key(self.module["tool"])
        names = self.site.zodiac.get(self.code, {})
        bar_from, bar_to = self.module["bar"]

        rows = []
        for item in tool["items"]:
            samples = "".join(
                f'<img src="{self.avatar(s["uid"])}" alt="{html.escape(s["name"], quote=True)}"'
                f' title="{html.escape(s["name"], quote=True)}" loading="lazy">'
                for s in item["samples"]
            )
            if item["sampleOverflow"]:
                more = (
                    '<span class="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-slate-100 dark:bg-slate-700'
                    ' text-[9px] sm:text-[10px] font-bold text-subtle flex items-center justify-center"'
                    f' title="{html.escape(self.t("toolbox.moreSamples", n=item["sampleOverflow"]), quote=True)}">'
                    f'+{item["sampleOverflow"]}</span>'
                )
            else:
                more = ""

            if item["subKind"] == "uidRange":
                sub = self.t("tool.uidRange", range=item["subValue"])
            elif item["subKind"] == "sameBirthday":
                sub = self.t("tool.sameBirthday", n=item["subValue"])
            else:
                sub = item["subValue"]

            icon_cell = (
                f'<span class="text-base sm:text-lg shrink-0" aria-hidden="true">'
                f'{html.escape(item["icon"])}</span>'
                if item.get("icon")
                else ""
            )
            rows.append(
                '''          <article class="rounded-2xl sm:rounded-3xl border border-slate-100 dark:border-slate-700 bg-white dark:bg-slate-800 p-3 sm:p-5 shadow-sm hover:shadow-md transition-shadow">
            <div class="flex items-center justify-between gap-2 sm:gap-3">
              <div class="min-w-0 flex items-center gap-1.5 sm:gap-3">
                <span class="text-[9px] sm:text-[10px] font-black w-5 h-5 sm:w-6 sm:h-6 rounded-md sm:rounded-lg bg-slate-100 dark:bg-slate-700 text-subtle flex items-center justify-center shrink-0">#{rank}</span>
                {icon}
                <div class="min-w-0">
                  <div class="text-xs sm:text-sm font-black text-main-color truncate">{name}</div>
                  <div class="text-[10px] sm:text-[11px] text-subtle">{sub}</div>
                </div>
              </div>
              <div class="text-right shrink-0">
                <div class="text-xs sm:text-sm font-black text-main-color">{count}</div>
                <div class="text-[10px] sm:text-[11px] text-subtle">{share}</div>
              </div>
            </div>
            <div class="tool-bar"><i style="width: {width}; background: linear-gradient(90deg, {bar_from}, {bar_to})"></i></div>
            <div class="tool-samples mt-3 sm:mt-4 flex flex-wrap items-center gap-1.5 sm:gap-2">{samples}{more}</div>
          </article>'''.format(
                    rank=item["rank"],
                    icon=icon_cell,
                    name=html.escape(names.get(item["name"], item["name"])),
                    sub=html.escape(sub),
                    count=html.escape(self.t("toolbox.people", n=item["count"])),
                    share=html.escape(item["shareText"]),
                    width=item["barWidth"],
                    bar_from=bar_from,
                    bar_to=bar_to,
                    samples=samples,
                    more=more,
                )
            )
        return render_file(
            "modules/tool.html",
            {
                "rows": "\n".join(rows),
                **self.head(
                    self.t("toolbox.count", n=self.site.toolbox["total"]),
                    self.back_to_toolbox(),
                ),
                **self.t_context(),
            },
        )

    def body_empty(self) -> str:
        blobs = self.module["blobs"]
        chips = self.module.get("chips") or []
        buttons = "".join(
            f'<button type="button" class="rank-chip" disabled>{html.escape(self.t(c))}</button>'
            for c in chips
        )
        if buttons:
            toolbar = (
                '<div class="flex flex-wrap items-center gap-1.5 sm:gap-2 opacity-60" aria-disabled="true" '
                f'title="{html.escape(self.t("state.disabledToolbar"), quote=True)}">{buttons}</div>'
            )
        elif self.module.get("tool"):
            # A sub-tool page: the only useful control is the way back to the hub.
            toolbar = self.back_to_toolbox()
        else:
            toolbar = ""
        if self.module.get("tool"):
            subtitle = self.t("toolbox.count", n=self.site.toolbox["total"])
        else:
            subtitle = self.t(f"module.{self.key}.subtitle")
        return render_file(
            "modules/empty.html",
            {
                "blobAccent": blobs[0],
                "blobAccent2": blobs[1],
                "stateIcon": self.module["icon"],
                "stateTitle": self.t(f"module.{self.key}.stateTitle"),
                "stateDetail": self.t(f"module.{self.key}.note"),
                **self.head(subtitle, toolbar),
                **self.t_context(),
            },
        )

    # ---- whole page

    def render(self) -> str:
        if self.module.get("tool") and self.module["state"] == "full":
            content = self.body_tool()
        else:
            builders = {
                "card": self.body_card,
                "ranking": self.body_ranking,
                "birthdays": self.body_birthdays,
                "toolbox": self.body_toolbox,
                "thanks": self.body_thanks,
            }
            content = builders.get(self.key, self.body_empty)()

        page_json = json.dumps(
            {
                "page": self.key,
                "locale": self.code,
                "state": self.module["state"],
                "stats": self.site.meta["stats"],
            },
            ensure_ascii=False,
            separators=(",", ":"),
        ).replace("<", "\\u003c")

        brand = self.loc["brand"]
        return render_file(
            "base.html",
            {
                "assetPrefix": self.prefix,
                "localeCode": self.code,
                "htmlLang": self.loc["htmlLang"],
                "ogLocale": self.loc["ogLocale"],
                "brand": brand,
                "pageKey": self.key,
                "pageTitle": f"{self.t(f'module.{self.key}.title')} | {brand}",
                "pageDescription": self.t("site.description"),
                "keywords": self.t("site.keywords"),
                "themeColor": self.site.meta["themeColor"],
                "ogImage": self.absolute("assets/img/logo.jpg"),
                "canonical": self.absolute(self.page_path(self.code, self.key)),
                "alternateLinks": self.alternates(),
                "homeFile": self.url_for(self.code, "card"),
                "brandUpdated": self.t(
                    "site.updated",
                    date=(self.site.creators.get("fetchedAt") or "")[:10],
                ),
                "brandTracked": self.t("site.tracked", n=self.creators_total()),
                "navDesktop": self.nav_items("100px"),
                "navMobile": self.nav_items("90px"),
                "langSwitchTitle": self.t("site.langSwitchTitle"),
                "langMenuItems": self.lang_menu(),
                "footerLanguages": self.footer_languages(),
                "content": content,
                "pageData": page_json,
                **self.t_context(),
            },
        )

    def output_path(self) -> Path:
        return SITE / (f"{self.dir}/{self.module['file']}" if self.dir else self.module["file"])


# --------------------------------------------------------------------- main


def copy_tree(src: Path, dst: Path, skip: set[str] | None = None) -> int:
    skip = skip or set()
    count = 0
    for path in src.rglob("*"):
        if path.is_dir():
            continue
        relative = path.relative_to(src)
        if relative.name in skip:
            continue
        target = dst / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        count += 1
    return count


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="run the validation pass afterwards")
    args = ap.parse_args()

    site = Site()
    if SITE.exists():
        shutil.rmtree(SITE)
    SITE.mkdir(parents=True)

    total = 0
    for locale in site.locales:
        size = 0
        for module in site.modules:
            builder = PageBuilder(site, locale["code"], module["key"])
            try:
                markup = builder.render()
            except MissingKey as err:
                print(f"!! {locale['code']}/{module['key']}: {err}", file=sys.stderr)
                return 1
            target = builder.output_path()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(markup, encoding="utf-8")
            size += len(markup)
            total += 1
        where = f"{locale['dir']}/" if locale["dir"] else "(root)"
        print(f"  {locale['code']:<8} {locale['label']:<6} {size:>9,}B  -> {where}")

    assets = copy_tree(ASSETS, SITE / "assets")
    # up.json / playcount.json are build inputs, not site assets: the pages inline
    # the data they need, so shipping the 10 MB full dump would just be dead weight.
    data_copies = copy_tree(DATA, SITE / "data", skip={"up.json", "playcount.json"})
    (SITE / ".nojekyll").write_text("", encoding="utf-8")

    print(f"\n  pages written : {total} ({len(site.modules)} modules × {len(site.locales)} languages)")
    print(f"  assets copied : {assets} files")
    print(f"  data copied   : {data_copies} files")

    if args.check:
        sys.path.insert(0, str(ROOT / "tools"))
        import validate  # noqa: PLC0415  (optional, only when --check)

        return validate.run()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

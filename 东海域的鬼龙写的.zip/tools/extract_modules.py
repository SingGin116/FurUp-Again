#!/usr/bin/env python3
"""Step 4: split the cleaned captures into one file per rendered panel.

For every nav tab we keep the section the capture rendered *visible*.  A tab can
hold several distinct panels — the toolbox is a hub with five sub-tools, each
captured separately — so those are written as <key>__<panel>.section.html next
to the tab's primary panel.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from lxml import etree, html as LH

ROOT = Path(__file__).resolve().parent.parent
CLEAN = ROOT / "work" / "clean"
MODULES = ROOT / "work" / "modules"

TABS = [
    ("card", "名片"),
    ("ranking", "排行榜"),
    ("birthdays", "生日日历"),
    ("costumes", "兽装"),
    ("meetups", "兽聚"),
    ("guide", "入圈指南"),
    ("recommend", "内容推荐"),
    ("artists", "创作者"),
    ("toolbox", "工具箱"),
    ("thanks", "鸣谢友链"),
]

# Panel titles that need a stable ASCII name (whitespace removed before lookup).
PANEL_KEYS = {
    "工具箱": "hub",
    "星座分布": "zodiac",
    "UID年代分布": "uid-era",
    "生日巧合榜": "birthday-pairs",
    "头像画风分布": "avatar-style",
    "头像主色调": "avatar-color",
}


def text(node) -> str:
    return re.sub(r"\s+", " ", node.text_content() or "").strip()


def panel_key(title: str) -> str:
    compact = re.sub(r"\s+", "", title)
    if compact in PANEL_KEYS:
        return PANEL_KEYS[compact]
    return re.sub(r"[^0-9A-Za-z]+", "-", compact).strip("-").lower() or "panel"


def inner(node) -> str:
    """Serialise a node's children only (drops the wrapper section)."""
    return "".join(
        etree.tostring(c, encoding="unicode", method="html") for c in node
    ).strip()


def main() -> None:
    MODULES.mkdir(parents=True, exist_ok=True)
    for stale in MODULES.glob("*"):
        stale.unlink()

    index = json.loads((CLEAN / "index.json").read_text(encoding="utf-8"))
    parsed: dict[str, Any] = {}
    for entry in index:
        parsed[entry["file"]] = LH.fromstring(
            (CLEAN / entry["file"]).read_text(encoding="utf-8")
        )

    report = []
    for key, label in TABS:
        candidates = []
        for entry in index:
            doc = parsed[entry["file"]]
            active = [text(b) for b in doc.xpath("//button[contains(@class,'module-tab--active')]")]
            if label not in active:
                continue
            visible = [
                s for s in doc.xpath("//section")
                if "display: none" not in (s.get("style") or "")
            ]
            if not visible:
                continue
            section = max(visible, key=lambda s: len(text(s)))
            heads = section.xpath(".//h2")
            candidates.append((entry, section, text(heads[0]) if heads else ""))

        if not candidates:
            print(f"!! no capture renders {label} as the active module")
            continue

        # Richest capture of each distinct panel wins.  Key on the normalised
        # panel key, not the raw title: "UID 年代分布" and "UID年代分布" are the
        # same panel and must not overwrite each other.
        panels: dict[str, tuple[dict, Any, int, str]] = {}
        for entry, section, title in candidates:
            pkey = panel_key(title)
            size = len(text(section))
            if pkey not in panels or size > panels[pkey][2]:
                panels[pkey] = (entry, section, size, title)

        primary_file = next((p[0]["file"] for p in panels.values() if p[0].get("primary")), None)

        for pkey, (entry, section, size, title) in panels.items():
            is_primary = entry["file"] == primary_file
            name = f"{key}.section.html" if is_primary else f"{key}__{pkey}.section.html"
            (MODULES / name).write_text(
                etree.tostring(section, encoding="unicode", method="html"), encoding="utf-8"
            )
            (MODULES / name.replace(".section.html", ".inner.html")).write_text(
                inner(section), encoding="utf-8"
            )
            report.append(
                {
                    "module": key,
                    "panel": title,
                    "panelKey": pkey,
                    "primary": is_primary,
                    "file": name,
                    "from": entry["file"],
                    "chars": size,
                    "headings": [text(h) for h in section.xpath(".//h1|.//h2|.//h3")][:4],
                }
            )
            print(f"{'*' if is_primary else ' '} {name:<40} panel={title or '-':<14} "
                  f"chars={size:<6} <- {entry['file']}")

    (MODULES / "index.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"\nwrote {len(report)} panel files -> work/modules/")


if __name__ == "__main__":
    main()

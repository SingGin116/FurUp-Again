﻿#!/usr/bin/env python3
"""Step 8: for every capture, describe the module panel that is actually visible."""

from __future__ import annotations

import re
from pathlib import Path

from lxml import html as LH

ROOT = Path(__file__).resolve().parent.parent.parent
CLEAN = ROOT / "work" / "clean"


def text(node) -> str:
    return re.sub(r"\s+", " ", node.text_content() or "").strip()


def digest(section, limit: int = 160) -> str:
    """A short human summary of what the panel holds."""
    bits = [text(h) for h in section.xpath(".//h2|.//h3")][:3]
    counts = [text(p) for p in section.xpath(".//p")][:2]
    body = text(section)
    return f"h={bits} p={counts} | {body[:limit]}"


def main() -> None:
    for path in sorted(CLEAN.glob("*.html")):
        doc = LH.fromstring(path.read_text(encoding="utf-8"))
        active = [text(b) for b in doc.xpath("//button[contains(@class,'module-tab--active')]")]
        visible = [
            s for s in doc.xpath("//section")
            if "display: none" not in (s.get("style") or "")
        ]
        print(f"\n=== {path.stem}  active={active}")
        for s in visible[:3]:
            print(f"    classes={s.get('class')}")
            print(f"    {digest(s)}")


if __name__ == "__main__":
    main()

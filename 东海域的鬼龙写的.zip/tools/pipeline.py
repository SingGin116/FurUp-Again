#!/usr/bin/env python3
"""Run the whole refactor pipeline in order.

    python tools/pipeline.py            # decode -> clean -> data -> assets -> build -> validate
    python tools/pipeline.py --from build

Every step is idempotent: it rewrites its own output directory and never touches
the original .mht files in the workspace root.
"""

from __future__ import annotations

import argparse
import importlib
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

STEPS = [
    ("extract_mht", "解包 .mht -> work/raw/*.html + work/parts/*"),
    ("clean", "剥离 Wayback 外壳 -> work/clean/*.html"),
    ("extract_modules", "按模块切分 -> work/modules/*"),
    ("extract_data", "抽取存档结构化数据 -> data/*.json"),
    ("fetch_playcount", "从 LetsFurry 接口按 uid 补播放量 -> data/playcount.json"),
    ("import_updata", "导入 up-data.js -> data/up.json + data/creators.json"),
    ("collect_assets", "收集并清理资源 -> assets/"),
    ("build", "渲染静态站点 -> site/"),
    ("validate", "校验收敛结果"),
]


def call(name: str) -> int:
    module = importlib.import_module(name)
    if name == "build":
        sys.argv = ["build"]
    result = module.main() if hasattr(module, "main") else module.run()
    return int(result or 0)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="start", default=STEPS[0][0],
                    choices=[s[0] for s in STEPS], help="start at this step")
    args = ap.parse_args()

    names = [s[0] for s in STEPS]
    start = names.index(args.start)

    for name, description in STEPS[start:]:
        print(f"\n=== {name} — {description} " + "=" * max(0, 40 - len(name)))
        began = time.perf_counter()
        code = call(name)
        elapsed = time.perf_counter() - began
        print(f"--- {name} {'ok' if code == 0 else f'FAILED ({code})'} in {elapsed:.1f}s")
        if code != 0:
            return code

    print("\n全部完成。用浏览器打开 site/index.html 即可。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

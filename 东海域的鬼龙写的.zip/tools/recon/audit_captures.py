#!/usr/bin/env python3
"""Audit every decoded capture: which panel is visible, and what does it hold?

This exists because clean.py collapses each tab down to its single richest
capture.  If two captures of the same tab render *different* panels, that
collapse silently throws content away.
"""

from __future__ import annotations

import json
import re
import sys
from collections import defaultdict
from pathlib import Path

from lxml import html as LH

ROOT = Path(__file__).resolve().parent.parent.parent
RAW = ROOT / "work" / "raw"


def text(node) -> str:
    return re.sub(r"\s+", " ", node.text_content() or "").strip()


def signature(section) -> str:
    """A content fingerprint that ignores wayback noise and volatile ids."""
    html = LH.tostring(section, encoding="unicode")
    html = re.sub(r'id="[^"]*"', "", html)
    html = re.sub(r'src="[^"]*"', "", html)
    html = re.sub(r"\s+", " ", html)
    return html[:1500]


def main() -> int:
    manifest = json.loads((RAW / "manifest.json").read_text(encoding="utf-8"))
    only = sys.argv[1] if len(sys.argv) > 1 else None

    groups: dict[str, list[dict]] = defaultdict(list)
    for entry in manifest:
        if "furup.me" not in (entry.get("location") or ""):
            continue
        if only and entry["slug"] != only:
            continue
        doc = LH.fromstring((ROOT / entry["html_file"]).read_text(encoding="utf-8", errors="replace"))
        active = [text(b) for b in doc.xpath("//button[contains(@class,'module-tab--active')]")][:1]
        visible = [s for s in doc.xpath("//section") if "display: none" not in (s.get("style") or "")]
        section = max(visible, key=lambda s: len(text(s))) if visible else None

        info = {
            "index": entry["index"],
            "bytes": entry["html_bytes"],
            "active": active[0] if active else "?",
            "h2": text(section.xpath(".//h2")[0]) if section is not None and section.xpath(".//h2") else "-",
            "sub": next(
                (text(p) for p in (section.xpath(".//p") if section is not None else []) if text(p)),
                "-",
            ),
            "text": text(section)[:150] if section is not None else "",
            # Prefix the panel title: the leading container markup is identical
            # across panels, so the first N characters alone never distinguish them.
            "sig": (
                (text(section.xpath(".//h2")[0]) if section.xpath(".//h2") else "?")
                + "|"
                + signature(section)[:400]
            )
            if section is not None
            else "",
            "source": entry["source"],
        }
        groups[entry["slug"]].append(info)

    for slug in sorted(groups):
        rows = sorted(groups[slug], key=lambda r: -r["bytes"])
        distinct = {r["sig"] for r in rows}
        print(f"\n=== {slug}: {len(rows)} captures, {len(distinct)} distinct panel(s) ===")
        for row in rows:
            print(f"  #{row['index']:02d} {row['bytes']:>8,}B  active={row['active']:<8} "
                  f"h2={row['h2']:<12} sub={row['sub'][:26]:<26} | {row['text'][:60]}")

        if len(distinct) > 1:
            seen = set()
            for row in rows:
                key = row["sig"]
                if key in seen:
                    continue
                seen.add(key)
                print(f"    -- distinct panel (from #{row['index']:02d}): "
                      f"h2={row['h2']} sub={row['sub'][:40]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

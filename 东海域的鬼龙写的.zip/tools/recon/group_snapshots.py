﻿#!/usr/bin/env python3
"""Step 2: group the decoded snapshots by tab and report candidate versions."""

from __future__ import annotations

import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).resolve().parent.parent.parent
RAW = ROOT / "work" / "raw"


def norm(text: str) -> str:
    """Rough content fingerprint: tags, wayback chrome and whitespace removed."""
    text = re.sub(r"<!--.*?-->", " ", text, flags=re.S)
    text = re.sub(r"<(script|style)\b.*?</\1>", " ", text, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"&[a-z]+;|&#\d+;", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def main() -> None:
    manifest = json.loads((RAW / "manifest.json").read_text(encoding="utf-8"))
    groups: dict[str, list[dict]] = defaultdict(list)

    for entry in manifest:
        html = (ROOT / entry["html_file"]).read_text(encoding="utf-8", errors="replace")
        loc = entry.get("location", "")
        qs = parse_qs(urlparse(loc).query)
        entry["tab"] = (qs.get("tab") or [""])[0]
        entry["host"] = urlparse(loc).netloc
        entry["fingerprint"] = hashlib.sha1(norm(html).encode()).hexdigest()[:10]
        entry["visible_chars"] = len(norm(html))
        entry["has_app"] = 'id="app"' in html
        groups[entry["slug"]].append(entry)

    for slug in sorted(groups):
        rows = sorted(groups[slug], key=lambda e: -e["html_bytes"])
        print(f"\n=== {slug}  ({len(rows)} captures, {len({r['fingerprint'] for r in rows})} distinct) ===")
        for r in rows:
            print(
                f"  #{r['index']:02d} {r['html_bytes']:>8,}B  vis={r['visible_chars']:>7,}  "
                f"app={int(r['has_app'])}  fp={r['fingerprint']}  tab={r['tab']!r}  {r['source'][:44]}"
            )

    # which fingerprints are unique to one slug
    print("\n=== distinct content per slug ===")
    seen: dict[str, str] = {}
    for slug in sorted(groups):
        fps = {r["fingerprint"] for r in groups[slug]}
        print(f"  {slug:<10} {len(fps)} distinct -> {sorted(fps)}")


if __name__ == "__main__":
    main()

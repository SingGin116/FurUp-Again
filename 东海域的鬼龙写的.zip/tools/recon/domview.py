﻿#!/usr/bin/env python3
"""Ad-hoc inspector for the cleaned snapshots.

    python tools/inspect.py <slug> [xpath] [--depth N] [--text] [--html] [--limit N]

Defaults to walking the #app subtree.  Handy because the captured markup is
minified onto very long lines.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

from lxml import html as LH, etree

ROOT = Path(__file__).resolve().parent.parent.parent
CLEAN = ROOT / "work" / "clean"
MODULES = ROOT / "work" / "modules"


def resolve(name: str) -> Path:
    """Accept a tab slug, a bare file name, or a workspace-relative path."""
    for base in (CLEAN, MODULES, ROOT):
        for candidate in (base / name, base / f"{name}.html"):
            if candidate.is_file():
                return candidate
    raise SystemExit(f"not found: {name}")


def label(node) -> str:
    tag = node.tag if isinstance(node.tag, str) else "?"
    out = tag
    if node.get("id"):
        out += f"#{node.get('id')}"
    cls = (node.get("class") or "").strip()
    if cls:
        out += "." + ".".join(cls.split()[:8])
    for attr in ("data-tab", "data-module", "data-tag", "data-name", "style"):
        if node.get(attr):
            out += f" [{attr}={node.get(attr)[:40]}]"
    return out


def walk(node, depth: int, max_depth: int, lines: list[str], pad: str = "") -> None:
    kids = [c for c in node if isinstance(c.tag, str)]
    own = re.sub(r"\s+", " ", node.text or "").strip()
    lines.append(f"{pad}{label(node)}  ({len(kids)} children){('  | ' + own[:70]) if own else ''}")
    if depth >= max_depth:
        if kids:
            lines.append(f"{pad}  ... {len(kids)} children elided")
        return
    for child in kids:
        walk(child, depth + 1, max_depth, lines, pad + "  ")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("slug")
    ap.add_argument("xpath", nargs="?", default="//*[@id='app']")
    ap.add_argument("--depth", type=int, default=2)
    ap.add_argument("--text", action="store_true")
    ap.add_argument("--html", action="store_true")
    ap.add_argument("--limit", type=int, default=40)
    args = ap.parse_args()

    path = resolve(args.slug)
    doc = LH.fromstring(path.read_text(encoding="utf-8"))
    nodes = doc.xpath(args.xpath)
    if not isinstance(nodes, list):
        nodes = [nodes]
    print(f"# {path.name}  xpath={args.xpath}  -> {len(nodes)} match(es)")

    for i, node in enumerate(nodes[: args.limit]):
        if not hasattr(node, "tag"):
            print(f"[{i}] {node!r}")
            continue
        if args.text:
            print(f"[{i}] {' '.join((node.text_content() or '').split())[:4000]}")
        elif args.html:
            print(f"[{i}] {etree.tostring(node, encoding='unicode', method='html')[:4000]}")
        else:
            lines: list[str] = []
            walk(node, 0, args.depth, lines)
            print(f"--- [{i}] " + "\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

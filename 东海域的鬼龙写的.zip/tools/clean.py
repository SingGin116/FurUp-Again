#!/usr/bin/env python3
"""Step 3: strip the Wayback Machine chrome out of the decoded snapshots.

Produces one HTML file per *distinct panel* the captures rendered.  A tab is
usually captured once, but some tabs (the toolbox) were captured several times
while showing different sub-views, so deduplicating by tab alone would silently
throw content away.  The richest panel of a tab lands in work/clean/<slug>.html
and any further distinct panel in work/clean/<slug>.<n>.html.
"""

from __future__ import annotations

import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

from lxml import etree, html as LH

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "work" / "raw"
CLEAN = ROOT / "work" / "clean"

WB_URL = re.compile(r"https?://web\.archive\.org/web/\d+(?:[a-z_]{2,3})?/")
ARCHIVE_RE = re.compile(r"archive\.org", re.I)

# Wayback injects a toolbar, a banner and a donate frame into every capture.
WB_ID_SELECTORS = ["wm-ipp-base", "wm-ipp", "wm-ipp-print", "donato", "wm-capinfo"]
WB_CLASS_SELECTORS = ["wb-autocomplete-suggestions"]


def xpath_literal(value: str) -> str:
    if "'" not in value:
        return f"'{value}'"
    if '"' not in value:
        return f'"{value}"'
    return "concat(" + ", \"'\", ".join(f"'{p}'" for p in value.split("'")) + ")"


def _host(url: str) -> str:
    m = re.match(r"https?://([^/]+)", url or "")
    return m.group(1).lower() if m else ""


def is_archive(url: str) -> bool:
    return bool(ARCHIVE_RE.search(_host(url)) or ARCHIVE_RE.search(url or ""))


def strip_wayback(doc) -> dict:
    stats = {"removed": 0, "rewritten": 0}
    drop: list = []

    for nid in WB_ID_SELECTORS:
        drop += doc.xpath(f"//*[@id={xpath_literal(nid)}]")
    for cls in WB_CLASS_SELECTORS:
        drop += doc.xpath(
            f"//*[contains(concat(' ', normalize-space(@class), ' '), ' {cls} ')]"
        )
    for node in doc.xpath("//link|//script|//iframe|//noscript"):
        if is_archive(node.get("href") or node.get("src") or ""):
            drop.append(node)

    for node in drop:
        if node.getparent() is not None:
            node.getparent().remove(node)
            stats["removed"] += 1

    for node in doc.iter():
        if not isinstance(node.tag, str):
            continue
        for attr in ("href", "src", "data-url", "content", "style"):
            value = node.get(attr)
            if value and "web.archive.org" in value:
                node.set(attr, WB_URL.sub("", value))
                stats["rewritten"] += 1
    return stats


def outline(node, depth: int = 0, max_depth: int = 3, lines: list[str] | None = None) -> list[str]:
    if lines is None:
        lines = []
    if depth > max_depth or not isinstance(node.tag, str):
        return lines
    classes = (node.get("class") or "").strip()
    nid = node.get("id")
    text = re.sub(r"\s+", " ", node.text or "").strip()[:56]
    label = node.tag
    if nid:
        label += f"#{nid}"
    if classes:
        label += "." + ".".join(classes.split()[:6])
    kids = len([c for c in node if isinstance(c.tag, str)])
    lines.append(f"{'  ' * depth}{label} [{kids}]{('  | ' + text) if text else ''}")
    if depth < max_depth:
        for child in node:
            outline(child, depth + 1, max_depth, lines)
    return lines


def panel_signature(doc) -> str:
    """Fingerprint of the panel a capture actually rendered.

    A tab can be captured several times while showing *different* sub-views
    (the toolbox does exactly this), so deduplicating by tab alone loses
    content.  Ids and srcs are stripped because they change between captures.
    """
    visible = [s for s in doc.xpath("//section") if "display: none" not in (s.get("style") or "")]
    if not visible:
        return ""
    block = max(visible, key=lambda s: len(s.text_content() or ""))
    markup = etree.tostring(block, encoding="unicode", method="html")
    markup = re.sub(r'\s(?:id|src|style)="[^"]*"', "", markup)
    return re.sub(r"\s+", " ", markup)[:2000]


def panel_title(doc) -> str:
    visible = [s for s in doc.xpath("//section") if "display: none" not in (s.get("style") or "")]
    if not visible:
        return ""
    block = max(visible, key=lambda s: len(s.text_content() or ""))
    heads = block.xpath(".//h2")
    return re.sub(r"\s+", " ", heads[0].text_content()).strip() if heads else ""


def main() -> int:
    import argparse

    ap = argparse.ArgumentParser(description="Strip the Wayback chrome from the decoded snapshots")
    ap.add_argument("--depth", type=int, default=3, help="DOM outline depth per page")
    args = ap.parse_args()
    max_depth = args.depth

    CLEAN.mkdir(parents=True, exist_ok=True)
    for stale in CLEAN.glob("*.html"):
        stale.unlink()
    manifest = json.loads((RAW / "manifest.json").read_text(encoding="utf-8"))

    # Group captures by tab, then by the panel they actually rendered.  Only the
    # richest capture of each distinct panel is worth keeping.
    by_tab: dict[str, list[dict]] = defaultdict(list)
    for entry in manifest:
        if "furup.me" not in (entry.get("location") or ""):
            continue  # QQ群.mht belongs to a different site
        by_tab[entry["slug"]].append(entry)

    index = []
    for slug in sorted(by_tab):
        groups: dict[str, list[tuple[dict, Any, str]]] = defaultdict(list)
        for entry in sorted(by_tab[slug], key=lambda e: -e["html_bytes"]):
            raw = (ROOT / entry["html_file"]).read_text(encoding="utf-8", errors="replace")
            doc = LH.fromstring(raw)
            app = doc.get_element_by_id("app")
            if app is None:
                continue
            groups[panel_signature(doc)].append((entry, doc, raw))

        ordered = sorted(groups.items(), key=lambda kv: -kv[1][0][0]["html_bytes"])
        for rank, (_signature, members) in enumerate(ordered):
            entry, _doc, raw = members[0]
            doc = LH.fromstring(raw)
            stats = strip_wayback(doc)
            app = doc.get_element_by_id("app")

            name = f"{slug}.html" if rank == 0 else f"{slug}.{rank}.html"
            out = CLEAN / name
            out.write_text(LH.tostring(doc, encoding="unicode", method="html"), encoding="utf-8")
            if rank == 0:
                (CLEAN / f"{slug}.outline.txt").write_text(
                    "\n".join(outline(app, max_depth=max_depth)), encoding="utf-8"
                )

            index.append(
                {
                    "slug": slug,
                    "file": name,
                    "primary": rank == 0,
                    "panel": panel_title(doc),
                    "from": entry["source"],
                    "capture_index": entry["index"],
                    "duplicates": len(members),
                    "bytes_in": entry["html_bytes"],
                    "bytes_out": len(LH.tostring(doc, encoding="unicode")),
                    **stats,
                }
            )
            print(
                f"{name:<20} {entry['html_bytes']:>8,}B  panel={panel_title(doc) or '-':<14} "
                f"dup={len(members):<2} urls={stats['rewritten']:<4} {entry['source'][:34]}"
            )

    (CLEAN / "index.json").write_text(
        json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"\ncleaned {len(index)} panels -> work/clean/")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

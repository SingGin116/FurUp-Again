#!/usr/bin/env python3
"""Step 1: unpack every .mht archive in the workspace into plain files.

Each archive is a MIME multipart/related document.  We keep:
  * the main text/html part  -> work/raw/<n>__<slug>.html
  * every other part (css / image / font) -> work/parts/<safe-name>
  * work/raw/manifest.json with per-archive metadata

Nothing is deleted: this stage only produces decoded copies for inspection.
"""

from __future__ import annotations

import json
import re
import sys
from email import policy
from email.parser import BytesParser
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "work" / "raw"
PARTS = ROOT / "work" / "parts"
ARCHIVE = ROOT / "archive"

SLUG_MAP = {
    "": "home",
    "thanks": "thanks",
    "ranking": "ranking",
    "trend": "trend",
    "birthday": "birthday",
    "events": "events",
    "guide": "guide",
    "recommend": "recommend",
    "artists": "artists",
    "toolbox": "toolbox",
    "studios": "studios",
    "fursuit": "studios",
}


WB_PREFIX = re.compile(r"^https?://web\.archive\.org/web/\d+(?:[a-z_]{2,3})?/")


def origin_host(loc: str) -> str:
    """Host of the file Wayback archived, with its rewrite prefix removed."""
    m = re.match(r"https?://([^/]+)", WB_PREFIX.sub("", loc or ""))
    return m.group(1).lower() if m else ""


def is_wayback_own(loc: str) -> bool:
    return origin_host(loc).endswith("archive.org")


def safe(name: str, fallback: str) -> str:
    """A readable filename for an asset, based on the original (pre-Wayback) URL."""
    original = WB_PREFIX.sub("", name or "")
    path = urlparse(original).path or fallback
    path = path.strip("/").replace("/", "_") or fallback
    path = re.sub(r"[^0-9A-Za-z._-]+", "_", path)
    return path[:120]


def tab_slug(url: str) -> str:
    qs = parse_qs(urlparse(url).query)
    tab = (qs.get("tab") or [""])[0]
    if tab in SLUG_MAP:
        return SLUG_MAP[tab]
    return re.sub(r"[^0-9A-Za-z]+", "-", tab).strip("-") or "unknown"


def main() -> int:
    RAW.mkdir(parents=True, exist_ok=True)
    PARTS.mkdir(parents=True, exist_ok=True)

    for stale in list(RAW.glob("*.html")) + list(PARTS.glob("*")):
        stale.unlink()

    manifest = []
    # Snapshots live in archive/; the workspace root is still accepted so an
    # un-filed .mht dropped next to the README keeps working.
    sources = sorted(ARCHIVE.glob("*.mht")) or sorted(ROOT.glob("*.mht"))
    if not sources:
        print("no .mht files found (looked in archive/ and the workspace root)", file=sys.stderr)
        return 1

    for index, path in enumerate(sources, start=1):
        data = path.read_bytes()
        msg = BytesParser(policy=policy.default).parsebytes(data)
        entry = {"source": path.name, "index": index, "parts": []}

        # The captured document is always the first text/html part; Wayback's
        # own frames (donate.php, banner) are appended after it and must not be
        # mistaken for the page.  Note the page's own Content-Location is also
        # rewritten to web.archive.org/..., so it cannot be filtered by host.
        main_html = None
        main_loc = ""
        for part in msg.walk():
            if part.is_multipart():
                continue
            ctype = part.get_content_type()
            loc = part.get("Content-Location", "") or ""
            payload = part.get_payload(decode=True)
            if payload is None:
                continue
            if ctype == "text/html":
                if main_html is None:
                    main_html, main_loc = payload, loc
                else:
                    entry["parts"].append({"type": ctype, "location": loc, "skipped": True})
                continue
            if is_wayback_own(loc):
                entry["parts"].append({"type": ctype, "location": loc, "skipped": True})
                continue

            out = PARTS / safe(loc, f"{index}-{len(entry['parts'])}")
            n = 1
            while out.exists() and out.read_bytes() != payload:
                out = out.with_name(f"{out.stem}~{n}{out.suffix}")
                n += 1
            out.write_bytes(payload)
            entry["parts"].append(
                {"type": ctype, "location": loc, "file": str(out.relative_to(ROOT)), "bytes": len(payload)}
            )

        if main_html is None:
            print(f"!! {path.name}: no furup.me html part", file=sys.stderr)
            continue

        slug = tab_slug(main_loc)
        entry["location"] = main_loc
        entry["slug"] = slug
        entry["html_bytes"] = len(main_html)
        html_name = f"{index:02d}__{slug}.html"
        (RAW / html_name).write_bytes(main_html)
        entry["html_file"] = f"work/raw/{html_name}"
        manifest.append(entry)
        print(f"{index:02d}  {slug:<10} {len(main_html):>8,}B  {path.name}")

    (RAW / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"\nwrote {len(manifest)} html files + manifest.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Validate the generated site: markup, links, CSS coverage, data and i18n.

    python tools/validate.py

Exit code 0 = all checks passed.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from pathlib import Path

from lxml import html as LH

ROOT = Path(__file__).resolve().parent.parent
SITE = ROOT / "site"
DATA = ROOT / "data"

CSS_FILES = ["assets/css/tailwind.css", "assets/css/site.css", "assets/css/app.css"]

# Characters Tailwind escapes when it writes a class name into CSS.
CSS_SPECIAL = set("!\"#$%&'()*+,./:;<=>?@[\\]^`{|}~")

FORBIDDEN = ["web.archive.org", "web-static.archive.org", '"https://furup.me/']

REQUIRED_STRINGS = [
    "site.description", "site.keywords", "site.footerNote", "site.footerContact", "site.footerLink",
    "site.footerSeo", "site.updated", "site.tracked", "site.searchPlaceholder", "site.searchLabel",
    "site.qqTitle", "site.themeToLight", "site.themeToDark", "site.backToTop", "site.navLabel",
    "site.navLabelMobile", "site.languageNav", "site.langSwitchTitle",
    "metric.fans", "metric.following", "metric.likes", "metric.plays",
    "card.birthdayTitle", "card.openSpace", "card.empty", "card.count",
    "ranking.subtitle", "ranking.top", "ranking.all", "ranking.hint",
    "birthdays.todayTitle", "birthdays.happy", "birthdays.prevMonth", "birthdays.nextMonth",
    "birthdays.cellTitle", "birthdays.weekdays",
    "toolbox.toolTitle", "toolbox.count", "toolbox.people",
    "state.archivedNote", "state.disabledToolbar",
    "common.all", "common.video", "common.article",
]


def css_escape(name: str) -> str:
    return "".join(("\\" + ch) if ch in CSS_SPECIAL else ch for ch in name)


class Report:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []

    def error(self, message: str) -> None:
        self.errors.append(message)

    def warn(self, message: str) -> None:
        self.warnings.append(message)


def load_css() -> str:
    return "\n".join((SITE / f).read_text(encoding="utf-8") for f in CSS_FILES)


# ----------------------------------------------------------------- markup


def check_pages(report: Report) -> list[Path]:
    pages = sorted(p for p in SITE.rglob("*.html") if "data" not in p.parts)
    if not pages:
        report.error("no pages generated in site/")
    return pages


def check_markup(report: Report, pages: list[Path], locales: list[dict]) -> dict[Path, object]:
    trees = {}
    by_dir = {entry["dir"]: entry for entry in locales}

    for page in pages:
        label = page.relative_to(SITE).as_posix()
        try:
            doc = LH.fromstring(page.read_bytes())
        except Exception as err:  # noqa: BLE001
            report.error(f"{label}: markup does not parse: {err}")
            continue
        trees[page] = doc

        ids = [e.get("id") for e in doc.xpath("//*[@id]")]
        duplicates = [i for i, n in Counter(ids).items() if n > 1]
        if duplicates:
            report.error(f"{label}: duplicate id(s): {duplicates}")

        if not doc.xpath("//title/text()"):
            report.error(f"{label}: missing <title>")
        if len(doc.xpath("//nav")) < 2:
            report.warn(f"{label}: expected two nav landmarks")

        # The document language must match the directory the page lives in.
        relative_dir = "" if page.parent == SITE else page.parent.name
        expected = by_dir.get(relative_dir)
        declared = (doc.xpath("string(/html/@lang)") or "").strip()
        if locales and expected is None:
            report.error(f"{label}: unexpected locale directory {relative_dir!r}")
        elif expected is not None and declared != expected["htmlLang"]:
            report.error(
                f"{label}: <html lang={declared!r}> does not match locale "
                f"{expected['code']} ({expected['htmlLang']!r})"
            )

        # Every page must offer every language, and declare the alternates once.
        alternates = doc.xpath("//link[@rel='alternate']/@hreflang")
        if alternates and len(alternates) != len(locales) + 1:
            report.error(
                f"{label}: expected {len(locales) + 1} hreflang alternates, found {len(alternates)}"
            )
        menu = doc.xpath("//*[@id='lang-switch']//a/@hreflang")
        if sorted(menu) != sorted(e["code"] for e in locales):
            report.error(f"{label}: language menu does not list every locale")

    return trees


def check_links(report: Report, trees: dict[Path, object]) -> int:
    checked = 0
    for page, doc in trees.items():
        for attr in ("href", "src"):
            for value in doc.xpath(f"//*[@{attr}]/@{attr}"):
                if not value or value.startswith(("#", "http://", "https://", "mailto:", "data:")):
                    continue
                target = (page.parent / value.split("#")[0].split("?")[0]).resolve()
                checked += 1
                if not target.exists():
                    report.error(f"{page.relative_to(SITE).as_posix()}: {attr}={value} does not exist")
    return checked


def check_class_coverage(report: Report, trees: dict[Path, object]) -> tuple[int, list[str]]:
    css = load_css()
    used: Counter[str] = Counter()
    for doc in trees.values():
        for value in doc.xpath("//@class"):
            for name in value.split():
                used[name] += 1

    missing = []
    for name in sorted(used):
        escaped = css_escape(name)
        if f".{escaped}" in css:
            continue
        if f".{escaped.replace(chr(92) + ',', chr(92) + '2c ')}" in css:
            continue
        missing.append(name)

    if missing:
        report.warn(
            f"{len(missing)} class(es) used in markup but not found in the stylesheets: "
            + ", ".join(missing[:25])
            + (" …" if len(missing) > 25 else "")
        )
    return len(used), missing


def check_forbidden(report: Report, pages: list[Path]) -> None:
    for page in pages:
        text = page.read_text(encoding="utf-8")
        for needle in FORBIDDEN:
            if needle in text:
                report.error(
                    f"{page.relative_to(SITE).as_posix()}: still references the archive/origin host ({needle})"
                )


# ----------------------------------------------------------------- data & i18n


def walk_people(node, found: dict[str, str]) -> None:
    if isinstance(node, dict):
        uid = node.get("uid")
        if isinstance(uid, str):
            found.setdefault(uid, node.get("name") if isinstance(node.get("name"), str) else "")
        for value in node.values():
            walk_people(value, found)
    elif isinstance(node, list):
        for value in node:
            walk_people(value, found)


def check_data(report: Report) -> dict[str, object]:
    names = ["site", "creators", "thanks", "birthdays", "toolbox", "modules", "avatars", "i18n"]
    payloads: dict[str, object] = {}
    for name in names:
        path = DATA / f"{name}.json"
        if not path.is_file():
            report.error(f"data/{name}.json is missing")
            continue
        try:
            payloads[name] = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as err:
            report.error(f"data/{name}.json is not valid JSON: {err}")

    if "creators" in payloads and payloads["creators"]["count"] != len(payloads["creators"]["items"]):
        report.error("creators.json: count does not match items length")
    if "thanks" in payloads and payloads["thanks"]["count"] != len(payloads["thanks"]["items"]):
        report.error("thanks.json: count does not match items length")

    if "birthdays" in payloads:
        b = payloads["birthdays"]
        if any(d["day"] is None for d in b["days"]):
            report.error("birthdays.json: some cells have no day number")
        today = [d for d in b["days"] if d["isToday"]]
        if len(today) != 1:
            report.error(f"birthdays.json: expected exactly one today cell, found {len(today)}")
        elif today[0]["total"] != len(b["today"]):
            report.warn(
                f"birthdays.json: today cell total ({today[0]['total']}) "
                f"differs from the listed people ({len(b['today'])})"
            )

    if "avatars" in payloads:
        avatar_map = payloads["avatars"]["map"]
        referenced: dict[str, str] = {}
        # creators.json (and up.json) now carry remote avatar URLs, so they are
        # not expected to be present in the local avatar map.
        for name in ("thanks", "birthdays", "toolbox"):
            if name in payloads:
                walk_people(payloads[name], referenced)
        unregistered = sorted(set(referenced) - set(avatar_map))
        if unregistered:
            report.error(f"{len(unregistered)} uid(s) have no avatar entry: {unregistered[:10]}")
        for rel in avatar_map.values():
            if str(rel).startswith("http"):
                continue
            if not (ROOT / rel).is_file():
                report.error(f"avatar file missing on disk: {rel}")
                break

    # The creator dataset now comes from the local up-data.js dump.
    if "creators" in payloads:
        creators = payloads["creators"]
        if "total" not in creators:
            report.error("creators.json: missing total (expected from up-data.js)")
        for item in creators.get("items", [])[:3]:
            for field in ("uid", "name", "fans", "following"):
                if field not in item:
                    report.error(f"creators.json: item is missing {field}")
                    break
            if not str(item.get("avatar", "")).startswith("http"):
                report.error(f"creators.json: {item.get('uid')} has a non-URL avatar")

    return payloads


def check_modules(report: Report, payloads: dict[str, object], locales: list[dict]) -> None:
    if "modules" not in payloads:
        return
    modules = payloads["modules"]["modules"]
    keys = [m["key"] for m in modules]
    if len(keys) != len(set(keys)):
        report.error("modules.json: duplicate module keys")

    for module in modules:
        for locale in locales:
            path = SITE / (f"{locale['dir']}/{module['file']}" if locale["dir"] else module["file"])
            if not path.is_file():
                report.error(f"{locale['code']}: {module['file']} was not generated")

        if module["state"] == "missing" and not module.get("blobs"):
            report.error(f"modules.json: {module['key']} is in the missing state but has no blobs")
        if module["state"] == "full" and module.get("tool") and not module.get("bar"):
            report.error(f"modules.json: tool page {module['key']} needs a bar gradient")

    # Sub-pages (tool pages) must point at a tool the data actually has.
    tool_keys = {t["key"] for t in payloads.get("toolbox", {}).get("tools", [])}
    for module in modules:
        if module.get("tool") and module["tool"] not in tool_keys:
            report.error(f"modules.json: {module['key']} refers to unknown tool {module['tool']!r}")

    nav_count = len([m for m in modules if m.get("nav", True)])
    if nav_count != 10:
        report.warn(f"modules.json: {nav_count} modules appear in the nav (expected 10)")


def check_toolbox(report: Report, payloads: dict[str, object]) -> None:
    if "toolbox" not in payloads or "modules" not in payloads:
        return
    tools = {t["key"] for t in payloads["toolbox"]["tools"]}
    declared = {m["tool"] for m in payloads["modules"]["modules"] if m.get("tool")}
    for key in sorted(declared - tools):
        report.error(f"modules.json declares tool {key!r} but toolbox.json has no such tool")
    for key in sorted(tools - declared):
        report.error(f"toolbox.json has tool {key!r} but no module declares it")

    for tool in payloads["toolbox"]["tools"]:
        if tool["state"] == "full" and not tool["items"]:
            report.error(f"toolbox.json: tool {tool['key']} is marked full but has no rows")
        for item in tool["items"]:
            if item["barWidth"] is None:
                report.warn(f"toolbox.json: {tool['key']} rank {item['rank']} has no bar width")
                break


def check_i18n(report: Report, payloads: dict[str, object]) -> list[dict]:
    if "i18n" not in payloads:
        return []
    i18n = payloads["i18n"]
    locales = i18n["locales"]
    strings = i18n["strings"]
    default = i18n["defaultLocale"]

    codes = [entry["code"] for entry in locales]
    if len(codes) != len(set(codes)):
        report.error("i18n.json: duplicate locale codes")
    if default not in codes:
        report.error(f"i18n.json: defaultLocale {default!r} is not listed in locales")

    for entry in locales:
        for field in ("code", "label", "htmlLang", "ogLocale", "brand"):
            if not entry.get(field):
                report.error(f"i18n.json: locale {entry.get('code')!r} is missing {field}")
        if entry["code"] == default and entry["dir"]:
            report.error("i18n.json: the default locale must live at the site root (dir must be empty)")
        if entry["code"] != default and not entry["dir"]:
            report.error(f"i18n.json: locale {entry['code']!r} needs a directory")

    reference = set(strings.get(default, {}))
    for code in codes:
        keys = set(strings.get(code, {}))
        if not keys:
            report.error(f"i18n.json: no strings for locale {code!r}")
            continue
        absent_from_locale = sorted(reference - keys)
        extra = sorted(keys - reference)
        if absent_from_locale:
            report.error(f"i18n.json: {code} is missing {len(absent_from_locale)} key(s): "
                         f"{absent_from_locale[:8]}")
        if extra:
            report.warn(f"i18n.json: {code} has {len(extra)} key(s) absent from {default}: {extra[:8]}")
        absent = [k for k in REQUIRED_STRINGS if k not in keys]
        if absent:
            report.error(f"i18n.json: {code} is missing required key(s): {absent}")

    if "modules" in payloads:
        for module in payloads["modules"]["modules"]:
            for code in codes:
                for key in (f"module.{module['key']}.label", f"module.{module['key']}.title"):
                    if key not in strings.get(code, {}):
                        report.error(f"i18n.json: {code} is missing {key}")
                if module["state"] == "missing":
                    # Tool pages derive their subtitle from the toolbox payload.
                    suffixes = ["stateTitle", "note"] if module.get("tool") else \
                        ["subtitle", "stateTitle", "note"]
                    for suffix in suffixes:
                        key = f"module.{module['key']}.{suffix}"
                        if key not in strings.get(code, {}):
                            report.error(f"i18n.json: {code} is missing {key}")
                for chip in module.get("chips", []):
                    if chip not in strings.get(code, {}):
                        report.error(f"i18n.json: {code} is missing chip string {chip}")
            head_key = module.get("headTitleKey")
            if head_key and any(head_key not in strings.get(code, {}) for code in codes):
                report.error(f"i18n.json: headTitleKey {head_key} is not translated everywhere")

    # The toolbox prints sign names straight from the data, so every non-Chinese
    # locale needs a mapping for all twelve of them.
    if "toolbox" in payloads:
        for code in codes:
            if code == "zh-Hans":
                continue
            table = i18n.get("zodiac", {}).get(code, {})
            for tool in payloads["toolbox"]["tools"]:
                for item in tool["items"]:
                    if item["icon"] and item["name"] not in table:
                        report.error(f"i18n.json: zodiac[{code}] is missing {item['name']!r}")
                        break

    return locales


def check_placeholders(report: Report, payloads: dict[str, object]) -> None:
    """Formatted strings must keep exactly the named fields the builder passes."""
    if "i18n" not in payloads:
        return
    expected = {
        "site.updated": {"date"},
        "site.tracked": {"n"},
        "card.birthdayTitle": {"d"},
        "card.openSpace": {"name"},
        "card.empty": {"term"},
        "card.count": {"n", "total"},
        "ranking.subtitle": {"n"},
        "ranking.top": {"n"},
        "birthdays.cellTitle": {"date", "n"},
        "toolbox.count": {"n"},
        "toolbox.people": {"n"},
        "module.thanks.subtitle": {"n"},
    }
    field = re.compile(r"\{(\w+)\}")
    for code, table in payloads["i18n"]["strings"].items():
        for key, want in expected.items():
            value = table.get(key)
            if value is None:
                continue
            got = set(field.findall(value))
            if got != want:
                report.error(f"i18n.json: {code} {key} uses {sorted(got)}, expected {sorted(want)}")


# ----------------------------------------------------------------- main


def run() -> int:
    report = Report()
    payloads = check_data(report)
    locales = check_i18n(report, payloads)
    check_modules(report, payloads, locales)
    check_toolbox(report, payloads)
    check_placeholders(report, payloads)

    pages = check_pages(report)
    trees = check_markup(report, pages, locales)
    links = check_links(report, trees)
    classes_used, missing = check_class_coverage(report, trees)
    check_forbidden(report, pages)

    print("=" * 72)
    print(f"languages    : {len(locales)}  {[e['code'] for e in locales]}")
    print(f"pages        : {len(pages)}")
    print(f"links/assets : {links} checked")
    print(f"css classes  : {classes_used} distinct, {len(missing)} undefined")
    print(f"errors       : {len(report.errors)}")
    print(f"warnings     : {len(report.warnings)}")
    print("=" * 72)

    for line in report.errors:
        print(f"ERROR   {line}")
    for line in report.warnings:
        print(f"WARN    {line}")

    return 1 if report.errors else 0


if __name__ == "__main__":
    raise SystemExit(run())

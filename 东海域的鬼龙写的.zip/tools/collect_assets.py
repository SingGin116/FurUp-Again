#!/usr/bin/env python3
"""Step 10: assemble the asset tree the rebuilt site needs.

    work/parts/*            (decoded MIME attachments from the captures)
        -> assets/css/tailwind.css   the site's compiled Tailwind build
        -> assets/css/site.css       the site's own stylesheet
        -> assets/img/logo.jpg
        -> assets/img/avatars/*.webp (only those the data actually references)
"""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PARTS = ROOT / "work" / "parts"
DATA = ROOT / "data"
ASSETS = ROOT / "assets"

TAILWIND_MARKER = "--tw-border-spacing-x"


def pick_tailwind() -> Path:
    """The biggest inline stylesheet that carries Tailwind's preflight."""
    candidates = [
        p for p in PARTS.glob("*.blink")
        if TAILWIND_MARKER in p.read_text(encoding="utf-8", errors="replace")[:400]
    ]
    if not candidates:
        raise SystemExit("no Tailwind build found among the saved parts")
    return max(candidates, key=lambda p: p.stat().st_size)


def referenced_people() -> dict[str, str]:
    """uid -> display name, gathered from every list of people in the data."""
    people: dict[str, str] = {}

    def walk(node) -> None:
        if isinstance(node, dict):
            uid, name = node.get("uid"), node.get("name")
            if isinstance(uid, str):
                people.setdefault(uid, name if isinstance(name, str) else "")
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for value in node:
                walk(value)

    # up.json / creators.json carry their own remote avatar URLs now, so skip
    # them — only the archive-derived lists still need local files/placeholders.
    for path in DATA.glob("*.json"):
        if path.name in ("up.json", "creators.json"):
            continue
        walk(json.loads(path.read_text(encoding="utf-8")))
    return people


PLACEHOLDER = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64" role="img" aria-label="{name}">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="hsl({hue} 72% 62%)"/>
      <stop offset="1" stop-color="hsl({hue2} 68% 44%)"/>
    </linearGradient>
  </defs>
  <rect width="64" height="64" fill="url(#g)"/>
  <text x="32" y="42" text-anchor="middle" font-family="Inter, system-ui, -apple-system, sans-serif"
        font-size="30" font-weight="700" fill="#ffffff">{initial}</text>
</svg>
"""


def write_placeholder(path: Path, uid: str, name: str) -> None:
    hue = int(uid[-4:]) % 360
    initial = (name or "?").strip()[:1] or "?"
    escaped = (
        initial.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    )
    safe_name = name.replace("&", "&amp;").replace("<", "&lt;").replace('"', "&quot;")
    path.write_text(
        PLACEHOLDER.format(hue=hue, hue2=(hue + 28) % 360, initial=escaped, name=safe_name),
        encoding="utf-8",
    )


def main() -> None:
    for sub in ("css", "js", "img/avatars"):
        (ASSETS / sub).mkdir(parents=True, exist_ok=True)

    tw = pick_tailwind()
    (ASSETS / "css" / "tailwind.css").write_text(
        "/* Compiled Tailwind build recovered from the archived captures.\n"
        f"   Source part: {tw.name} ({tw.stat().st_size:,} bytes) */\n\n"
        + tw.read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    print(f"  css/tailwind.css   <- {tw.name} ({tw.stat().st_size:,}B)")

    site_css = PARTS / "assets_styles.css"
    shutil.copyfile(site_css, ASSETS / "css" / "site.css")
    print(f"  css/site.css       <- {site_css.name} ({site_css.stat().st_size:,}B)")

    logo = PARTS / "assets_logo.jpg"
    shutil.copyfile(logo, ASSETS / "img" / "logo.jpg")
    print(f"  img/logo.jpg       <- {logo.name} ({logo.stat().st_size:,}B)")

    available = {}
    for part in PARTS.glob("avatars_*.webp"):
        m = re.match(r"avatars_(\d+)\.webp$", part.name)
        if m:
            available[m.group(1)] = part

    people = referenced_people()
    avatar_map: dict[str, str] = {}
    real, placeholder = 0, 0
    for uid, name in sorted(people.items()):
        part = available.get(uid)
        if part:
            shutil.copyfile(part, ASSETS / "img" / "avatars" / f"{uid}.webp")
            avatar_map[uid] = f"assets/img/avatars/{uid}.webp"
            real += 1
        else:
            write_placeholder(ASSETS / "img" / "avatars" / f"{uid}.svg", uid, name)
            avatar_map[uid] = f"assets/img/avatars/{uid}.svg"
            placeholder += 1

    (DATA / "avatars.json").write_text(
        json.dumps(
            {
                "note": "uid -> avatar path. .webp files are the archived originals; "
                        ".svg files are generated initials placeholders.",
                "total": len(avatar_map),
                "archived": real,
                "placeholder": placeholder,
                "map": avatar_map,
            },
            ensure_ascii=False,
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )
    print(f"  img/avatars/       {real} archived + {placeholder} placeholders "
          f"= {len(avatar_map)} referenced")


if __name__ == "__main__":
    main()

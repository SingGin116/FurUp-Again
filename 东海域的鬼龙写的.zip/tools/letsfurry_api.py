#!/usr/bin/env python3
"""Minimal, polite client for the public LetsFurry API.

    python tools/letsfurry_api.py --probe          # shape of every known endpoint

The site operator has authorised this rebuild, so we identify ourselves, keep a
courtesy delay between requests, retry transient failures and cache every
response on disk under work/crawl/api/ so re-runs never re-hit the server.
"""

from __future__ import annotations

import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
CACHE = ROOT / "work" / "crawl" / "api"

BASE = "https://api.letsfurry.com"
SITE = "https://www.letsfurry.com"

USER_AGENT = (
    "FurUp-Archive-Rebuild/1.0 (+https://github.com/local/furup-rebuild; "
    "static site reconstruction, authorised by the site operator)"
)

MIN_INTERVAL = 1.0   # seconds between live requests
TIMEOUT = 60.0
RETRIES = 3

_last_call = 0.0
_stats = {"hit": 0, "miss": 0, "error": 0}


def _slug(path: str, params: dict[str, Any] | None) -> str:
    name = path.strip("/").replace("/", "_")
    if params:
        query = urllib.parse.urlencode(sorted(params.items()))
        name += "__" + query.replace("&", "_").replace("=", "-")
    return name[:180] + ".json"


def get(path: str, params: dict[str, Any] | None = None, *, cache: bool = True) -> Any:
    """GET a public endpoint, with an on-disk cache and a courtesy delay."""
    global _last_call

    params = {k: v for k, v in (params or {}).items() if v is not None}
    CACHE.mkdir(parents=True, exist_ok=True)
    cached = CACHE / _slug(path, params)
    if cache and cached.is_file():
        _stats["hit"] += 1
        return json.loads(cached.read_text(encoding="utf-8"))

    url = BASE + path
    if params:
        url += "?" + urllib.parse.urlencode(params)

    headers = {
        "accept": "application/json",
        "user-agent": USER_AGENT,
        "referer": SITE + "/",
        "origin": SITE,
    }

    last_error: Exception | None = None
    for attempt in range(RETRIES):
        wait = MIN_INTERVAL - (time.monotonic() - _last_call)
        if wait > 0:
            time.sleep(wait)
        _last_call = time.monotonic()

        request = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT) as response:
                payload = json.loads(response.read().decode("utf-8"))
            _stats["miss"] += 1
            if cache:
                cached.write_text(
                    json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
                )
            return payload
        except urllib.error.HTTPError as err:
            body = err.read()[:200].decode("utf-8", "replace")
            last_error = RuntimeError(f"HTTP {err.code} for {url} — {body}")
            if err.code in (429, 500, 502, 503, 504):
                time.sleep(2.0 * (attempt + 1))
                continue
            break
        except Exception as err:  # noqa: BLE001
            last_error = err
            time.sleep(1.5 * (attempt + 1))

    _stats["error"] += 1
    raise RuntimeError(f"request failed: {url}: {last_error}")


def probe_targets() -> list[tuple[str, dict[str, Any]]]:
    """The endpoints this rebuild actually needs, with real parameters."""
    base = {"metric": "followers", "schema": "site-loadout-v1"}
    return [
        ("/public/furup/ranking", {**base, "limit": 7000}),
        ("/public/furup/ranking", {**base, "limit": 1000}),
    ]


def probe() -> int:
    targets = probe_targets()
    print(f"probing {len(targets)} calls with a {MIN_INTERVAL}s delay\n")
    for path, params in targets:
        label = path + (("?" + urllib.parse.urlencode(params)) if params else "")
        try:
            payload = get(path, params)
        except Exception as err:  # noqa: BLE001
            print(f"  {label}\n      FAILED: {err}\n")
            continue
        print(f"  {label}\n      {shape(payload)}\n")

    print(f"cache hits={_stats['hit']} live={_stats['miss']} errors={_stats['error']}")
    return 0


def shape(payload: Any, depth: int = 0) -> str:
    if isinstance(payload, dict):
        keys = list(payload.keys())
        parts = [f"{k}={shape(payload[k], depth + 1)}" for k in keys[:8]]
        if len(keys) > 8:
            parts.append(f"…+{len(keys) - 8}")
        return "{" + ", ".join(parts) + "}"
    if isinstance(payload, list):
        if not payload:
            return "[]"
        return f"[{len(payload)} × {shape(payload[0], depth + 1)}]"
    if isinstance(payload, str):
        return f"str({payload[:24]!r})" if len(payload) > 24 else f"str({payload!r})"
    return repr(payload)


def main() -> int:
    if "--probe" in sys.argv:
        return probe()
    print(__doc__)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

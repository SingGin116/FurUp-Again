#!/usr/bin/env python3
"""Step 9: pull the recovered content out of the cleaned snapshots into data/*.json.

Everything the public site still shows is derived from here, so this script is
the only place that knows about the archived markup.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from lxml import html as LH

ROOT = Path(__file__).resolve().parent.parent
CLEAN = ROOT / "work" / "clean"
MODULES = ROOT / "work" / "modules"
DATA = ROOT / "data"

AVATAR_RE = re.compile(r"/avatars/(\d+)\.webp")


# --------------------------------------------------------------------------- helpers


def text(node) -> str:
    return re.sub(r"\s+", " ", node.text_content() or "").strip()


def classed(node, *fragments: str) -> bool:
    cls = node.get("class") or ""
    return all(f in cls for f in fragments)


def parse_count(display: str, exact: str | None = None) -> int | None:
    """'1.6万' -> 16000, '4,477' -> 4477.  Prefers an exact title when present."""
    if exact:
        digits = re.sub(r"[^\d]", "", exact)
        if digits:
            return int(digits)
    raw = (display or "").strip().replace(",", "")
    m = re.match(r"^([\d.]+)\s*(万|亿|w|k)?$", raw, re.I)
    if not m:
        return None
    value = float(m.group(1))
    unit = (m.group(2) or "").lower()
    factor = {"万": 10_000, "w": 10_000, "亿": 100_000_000, "k": 1_000}.get(unit, 1)
    return int(round(value * factor))


def avatar(uid: str) -> str:
    return f"assets/img/avatars/{uid}.webp"


# --------------------------------------------------------------------------- people cards


def parse_person_cards(page: str) -> tuple[list[dict[str, Any]], list[str]]:
    """The 名片/鸣谢 grids share one card component."""
    doc = LH.fromstring((CLEAN / page).read_text(encoding="utf-8"))
    cards, warnings = [], []

    for article in doc.xpath("//*[@id='cards-grid']/article"):
        uid = (article.get("id") or "").removeprefix("card-")
        img = article.xpath(".//img")[0]
        src_uid = AVATAR_RE.search(img.get("src") or "")
        if src_uid and src_uid.group(1) != uid:
            warnings.append(f"{page}: card id {uid} but avatar uid {src_uid.group(1)}")

        name = text(article.xpath(".//h2")[0])

        birthday = None
        for span in article.xpath(".//span[@title]"):
            m = re.match(r"Birthday:\s*(\d{2}-\d{2})", span.get("title") or "")
            if m:
                birthday = m.group(1)
                break

        # Metric cells: 粉丝 / 获赞 / 播放
        cells = article.xpath(".//div[contains(@class,'grid-cols-3')]/div")
        metrics = {}
        for cell in cells[:3]:
            label = text(cell.xpath("./div[1]")[0])
            value_node = cell.xpath("./span[1]")[0]
            metrics[label] = {
                "display": text(value_node),
                "exact": value_node.get("title"),
            }
        for want in ("粉丝", "获赞", "播放"):
            if want not in metrics:
                warnings.append(f"{page}: card {uid} missing metric {want}")

        # Any badge next to the birthday chip (studio / verified markers).
        tags: list[str] = []
        for holder in article.xpath(".//div[contains(@class,'min-h-[1.25rem]')]"):
            for child in holder:
                if not isinstance(child.tag, str):
                    continue
                label = text(child)
                if label and child.get("title", "").startswith("Birthday:"):
                    continue
                if label:
                    tags.append(label)

        plays = metrics.get("播放", {})
        fans = metrics.get("粉丝", {})
        likes = metrics.get("获赞", {})
        cards.append(
            {
                "uid": uid,
                "name": name,
                "avatar": avatar(uid),
                "birthday": birthday,
                "fans": parse_count(fans.get("display", ""), fans.get("exact")),
                "fansText": fans.get("display", ""),
                "likes": parse_count(likes.get("display", ""), likes.get("exact")),
                "likesText": likes.get("display", ""),
                "plays": parse_count(plays.get("display", ""), plays.get("exact")),
                "playsText": plays.get("display", ""),
                "tags": tags,
                "space": f"https://space.bilibili.com/{uid}",
            }
        )
    return cards, warnings


# --------------------------------------------------------------------------- birthdays


def parse_birthdays() -> dict[str, Any]:
    doc = LH.fromstring((MODULES / "birthdays.section.html").read_text(encoding="utf-8"))

    month_label = ""
    for p in doc.xpath("//p"):
        if re.match(r"^\d{4}年\d{1,2}月$", text(p)):
            month_label = text(p)
            break
    month_iso = ""
    m = re.match(r"^(\d{4})年(\d{1,2})月$", month_label)
    if m:
        month_iso = f"{m.group(1)}-{int(m.group(2)):02d}"

    weekdays = [text(d) for d in doc.xpath("//div[contains(@class,'weekday-header')]/div")]

    days = []
    today_day = None
    for cell in doc.xpath("//div[contains(@class,'birthday-cell')]"):
        classes = cell.get("class") or ""
        number = text(cell.xpath(".//span[contains(@class,'font-mono')][1]")[0]) if cell.xpath(
            ".//span[contains(@class,'font-mono')]"
        ) else ""
        people = []
        for img in cell.xpath(".//div[contains(@class,'avatar-stack')]/img"):
            src_uid = AVATAR_RE.search(img.get("src") or "")
            if src_uid:
                people.append({"uid": src_uid.group(1), "name": img.get("alt") or ""})
        overflow = 0
        for badge in cell.xpath(".//div[contains(@class,'avatar-stack')]/div"):
            mm = re.match(r"\+\s*(\d+)", text(badge))
            if mm:
                overflow = int(mm.group(1))
        day_number = int(number) if number.isdigit() else None
        if "birthday-cell--today" in classes:
            today_day = day_number
        days.append(
            {
                "day": day_number,
                "weekend": "birthday-cell--weekend" in classes,
                "isToday": "birthday-cell--today" in classes,
                "people": people,
                "overflow": overflow,
                "total": len(people) + overflow,
            }
        )

    todays = []
    for item in doc.xpath("//h3[contains(.,'今日生日')]/following-sibling::div/div"):
        img = item.xpath(".//img")
        name = item.xpath(".//div[contains(@class,'font-bold')]")
        if not img or not name:
            continue
        src_uid = AVATAR_RE.search(img[0].get("src") or "")
        if not src_uid:
            continue
        todays.append({"uid": src_uid.group(1), "name": text(name[0]), "avatar": avatar(src_uid.group(1))})

    return {
        "month": month_iso,
        "monthLabel": month_label,
        "weekdays": weekdays,
        "todayDay": today_day,
        "todayLabel": f"{month_iso}-{today_day:02d}" if today_day else None,
        "today": todays,
        "days": days,
    }


# --------------------------------------------------------------------------- toolbox


TOOL_PANELS = {
    "星座分布": "zodiac",
    "UID 年代分布": "uid-era",
    "UID年代分布": "uid-era",
    "生日巧合榜": "birthday-pairs",
    "头像画风分布": "avatar-style",
    "头像主色调": "avatar-color",
}


def tool_panel_path(panel_key: str) -> Path:
    """The extracted section for one toolbox sub-tool."""
    if panel_key == "zodiac":
        return MODULES / "toolbox.section.html"
    return MODULES / f"toolbox__{panel_key}.section.html"


def parse_tool_header(doc) -> tuple[str, str]:
    head = doc.xpath("//h2")
    title = text(head[0]) if head else ""
    subtitle = next((text(p) for p in doc.xpath("//p") if "位创作者" in text(p)), "")
    return title, subtitle


def classify_sub(sub: str) -> tuple[str, str, Any]:
    """Split a row's sub-label into a translatable kind plus its value.

    Some sub-labels are pure data (a zodiac date range) and stay verbatim;
    others are UI phrasing around a value and get translated at build time.
    """
    m = re.fullmatch(r"约注册于[:：]\s*(.+)", sub)
    if m:
        return sub, "uidRange", m.group(1).strip()
    m = re.fullmatch(r"([\d,]+)\s*人同天生日", sub)
    if m:
        return sub, "sameBirthday", int(m.group(1).replace(",", ""))
    return sub, "literal", sub


def parse_tool_rows(doc) -> tuple[list[dict[str, Any]], str | None]:
    """Every toolbox sub-tool renders the same ranked-row component."""
    items = []
    bar_gradient = None

    for article in doc.xpath("//article"):
        spans = article.xpath("./div[1]/div[1]/span")
        rank = text(spans[0]) if spans else ""
        tool_icon = text(spans[1]) if len(spans) > 1 else None

        name = text(article.xpath(".//div[contains(@class,'font-black')][1]")[0])
        sub = text(article.xpath(".//div[contains(@class,'text-subtle')][1]")[0])
        count_text = text(article.xpath(".//div[contains(@class,'text-right')]//div[1]")[0])
        share_text = text(article.xpath(".//div[contains(@class,'text-right')]//div[2]")[0])

        bar = article.xpath(".//div[contains(@class,'rounded-full')]/div")
        style = (bar[0].get("style") or "") if bar else ""
        bar_classes = (bar[0].get("class") or "") if bar else ""
        if bar_gradient is None and "from-" in bar_classes:
            bar_gradient = " ".join(c for c in bar_classes.split() if c.startswith(("from-", "to-")))
        width = re.search(r"width:\s*([\d.]+%)", style)

        samples = []
        for img in article.xpath(".//img"):
            src_uid = AVATAR_RE.search(img.get("src") or "")
            if src_uid:
                samples.append({"uid": src_uid.group(1), "name": img.get("alt") or ""})

        # The original shows five avatars plus a "+N" chip.  The hidden avatars
        # were never archived, so the chip keeps the archived number verbatim
        # instead of pretending we know how many more there really are.
        overflow = 0
        for node in article.xpath(".//*[self::button or self::div][not(.//img)]"):
            m = re.fullmatch(r"\+\s*(\d+)", text(node))
            if m:
                overflow = int(m.group(1))
                break

        mm = re.search(r"([\d,]+)\s*人", count_text)
        share = share_text.rstrip("%")
        sub_text, sub_kind, sub_value = classify_sub(sub)
        items.append(
            {
                "rank": int(rank.lstrip("#")) if rank.lstrip("#").isdigit() else None,
                "icon": tool_icon,
                "name": name,
                "sub": sub_text,
                "subKind": sub_kind,
                "subValue": sub_value,
                "count": int(mm.group(1).replace(",", "")) if mm else None,
                "countText": count_text,
                "share": float(share) if share.replace(".", "", 1).isdigit() else None,
                "shareText": share_text,
                "barWidth": width.group(1) if width else None,
                "samples": samples,
                "sampleOverflow": overflow,
            }
        )
    return items, bar_gradient


def parse_toolbox() -> dict[str, Any]:
    """The toolbox is a hub linking to five sub-tools; three have real data."""
    hub = LH.fromstring(tool_panel_path("hub").read_text(encoding="utf-8"))
    title, subtitle = parse_tool_header(hub)

    total = None
    m = re.search(r"([\d,]+)\s*位创作者", subtitle)
    if m:
        total = int(m.group(1).replace(",", ""))

    tools = []
    for card in hub.xpath("//button"):
        icon_span = card.xpath(".//div[contains(@class,'bg-gradient-to-br')]/span")
        name_node = card.xpath(".//div[contains(@class,'font-black')][1]")
        desc_node = card.xpath(".//div[contains(@class,'line-clamp-2')][1]")
        badge = card.xpath(".//span[contains(@class,'rounded-full')]")
        accent_node = card.xpath(".//div[contains(@class,'bg-gradient-to-br')]")
        if not name_node:
            continue
        name = text(name_node[0])
        key = TOOL_PANELS.get(re.sub(r"\s+", "", name), TOOL_PANELS.get(name, ""))
        if not key:
            key = re.sub(r"[^0-9A-Za-z]+", "-", name).strip("-").lower() or "tool"

        accent = ""
        if accent_node:
            accent = " ".join(
                c for c in (accent_node[0].get("class") or "").split()
                if c.startswith(("from-", "to-"))
            )

        entry = {
            "key": key,
            "icon": text(icon_span[0]) if icon_span else "",
            "accent": accent,
            "name": name,
            "description": text(desc_node[0]) if desc_node else "",
            "rowCount": int(text(badge[0])) if badge and text(badge[0]).isdigit() else 0,
            "state": "full",
            "items": [],
            "subtitle": subtitle,
            "barGradient": None,
        }

        panel = tool_panel_path(key)
        if panel.is_file():
            doc = LH.fromstring(panel.read_text(encoding="utf-8"))
            panel_title, panel_subtitle = parse_tool_header(doc)
            rows, gradient = parse_tool_rows(doc)
            entry["panelTitle"] = panel_title
            entry["subtitle"] = panel_subtitle or subtitle
            entry["items"] = rows
            entry["barGradient"] = gradient
            if not rows:
                entry["state"] = "missing"
        else:
            entry["state"] = "missing"
            entry["panelTitle"] = name

        tools.append(entry)

    return {"title": title, "subtitle": subtitle, "total": total, "tools": tools}


# --------------------------------------------------------------------------- site chrome


def parse_site() -> dict[str, Any]:
    doc = LH.fromstring((CLEAN / "home.html").read_text(encoding="utf-8"))

    def meta(selector: str) -> str:
        found = doc.xpath(selector)
        if isinstance(found, str):  # XPath string() functions return a bare str
            return re.sub(r"\s+", " ", found).strip()
        return found[0] if found else ""

    nav = []
    for button in doc.xpath("//nav//button[contains(@class,'module-tab')]"):
        nav.append({"label": text(button), "active": "module-tab--active" in (button.get("class") or "")})

    # Keep only real text nodes: the brand line is separated by decorative dots.
    brand_meta = [
        t for t in (text(d) for d in doc.xpath("//div[contains(@class,'furup-brand-meta')]//*"))
        if t and t not in {"•", "·", "|"}
    ]

    return {
        "title": meta("string(//title)"),
        "description": meta("//meta[@name='description']/@content"),
        "keywords": meta("//meta[@name='keywords']/@content"),
        "ogTitle": meta("//meta[@property='og:title']/@content"),
        "ogDescription": meta("//meta[@property='og:description']/@content"),
        "ogImage": "assets/img/logo.jpg",
        "themeColor": meta("//meta[@name='theme-color']/@content"),
        "baseUrl": "",
        "brandMeta": brand_meta[:4],
        "nav": nav[:10],
        "footer": [text(p) for p in doc.xpath("//*[@id='app']/footer//p") if text(p)],
    }


# --------------------------------------------------------------------------- main


def dump(name: str, payload: Any) -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    path = DATA / f"{name}.json"
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    size = path.stat().st_size
    print(f"  data/{name}.json  {size:>7,}B")


def main() -> None:
    warnings: list[str] = []

    creators, w = parse_person_cards("home.html")
    warnings += w
    thanks, w = parse_person_cards("thanks.html")
    warnings += w
    birthdays = parse_birthdays()
    toolbox = parse_toolbox()
    site = parse_site()

    site["stats"] = {
        "creators": len(creators),
        "thanks": len(thanks),
        "trackedCreators": toolbox["total"],
        "birthdayMonth": birthdays["monthLabel"],
        "birthdayToday": len(birthdays["today"]),
    }

    dump("site", site)
    dump("creators", {"count": len(creators), "items": creators})
    dump("thanks", {"count": len(thanks), "items": thanks})
    dump("birthdays", birthdays)
    dump("toolbox", toolbox)

    full = [t for t in toolbox["tools"] if t["state"] == "full"]
    print(f"\ncreators={len(creators)} thanks={len(thanks)} "
          f"birthdayDays={len(birthdays['days'])} today={len(birthdays['today'])} "
          f"tools={len(toolbox['tools'])} ({len(full)} with data) tracked={toolbox['total']}")
    for tool in toolbox["tools"]:
        print(f"  tool {tool['key']:<16} {tool['state']:<8} rows={len(tool['items'])}")
    if warnings:
        print(f"\n{len(warnings)} warning(s):")
        for line in warnings[:20]:
            print("  ! " + line)


if __name__ == "__main__":
    main()

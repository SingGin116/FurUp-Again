﻿#!/usr/bin/env python3
"""Print context around a pattern in a (possibly single-line) minified file.

    python tools/js_grep.py <file> <pattern> [--before N] [--after N] [--max N]
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("pattern")
    ap.add_argument("--before", type=int, default=200)
    ap.add_argument("--after", type=int, default=800)
    ap.add_argument("--max", type=int, default=5)
    args = ap.parse_args()

    path = Path(args.file)
    if not path.is_file():
        path = ROOT / args.file
    text = path.read_text(encoding="utf-8", errors="replace")

    hits = list(re.finditer(args.pattern, text))
    print(f"# {path.name}  /{args.pattern}/  -> {len(hits)} match(es)")
    for i, m in enumerate(hits[: args.max]):
        start = max(0, m.start() - args.before)
        end = min(len(text), m.end() + args.after)
        print(f"--- [{i}] @{m.start()}")
        print(text[start:end])
        print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

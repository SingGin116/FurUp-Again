/* ---------------------------------------------------------------------------
 * app.js — 重构后重写的交互层。
 *
 * 原站的交互全部来自打包后的 Vue 客户端脚本，网页存档没有保留任何 JS，
 * 因此这里用原生 JS 重新实现页面上真正需要的几个行为：
 *   1. 深色 / 浅色主题切换（原站用 <html data-theme> 驱动 Tailwind 的 dark: 变体）
 *   2. 顶部搜索框按昵称过滤名片/鸣谢卡片
 *   3. 排行榜的指标切换与前 N 名筛选
 *   4. 移动端导航两端的渐隐提示
 *   5. 回到顶部按钮
 * 页面内容本身是构建时静态生成的，脚本只做增强，禁用 JS 也能正常阅读。
 * ------------------------------------------------------------------------- */
(function () {
  'use strict';

  var THEME_KEY = 'furup:theme';

  function readPageData() {
    var node = document.getElementById('page-data');
    if (!node) return {};
    try {
      return JSON.parse(node.textContent || '{}');
    } catch (err) {
      console.warn('[furup] 无法解析页面数据', err);
      return {};
    }
  }

  /* ----------------------------------------------------------------- 主题 */

  function initTheme() {
    var root = document.documentElement;
    var button = document.getElementById('theme-toggle');
    var icon = button && button.querySelector('[data-theme-icon]');
    var titleLight = (button && button.dataset.titleLight) || '浅色';
    var titleDark = (button && button.dataset.titleDark) || '深色';

    var stored = null;
    try {
      stored = localStorage.getItem(THEME_KEY);
    } catch (err) {
      stored = null;
    }
    if (stored === 'dark' || stored === 'light') {
      root.dataset.theme = stored;
    }

    function paint() {
      var dark = root.dataset.theme === 'dark';
      if (icon) icon.textContent = dark ? '☀' : '☾';
      if (button) button.title = dark ? titleLight : titleDark;
    }

    paint();
    if (!button) return;

    button.addEventListener('click', function () {
      root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
      try {
        localStorage.setItem(THEME_KEY, root.dataset.theme);
      } catch (err) {
        /* 隐私模式下忽略 */
      }
      paint();
    });
  }

  /* --------------------------------------------------------- 语言切换菜单 */

  function initLangSwitch() {
    var box = document.getElementById('lang-switch');
    if (!box) return;

    // <details> 自带开合，这里只补上「点外面 / 按 Esc 关闭」的习惯行为。
    document.addEventListener('click', function (event) {
      if (box.open && !box.contains(event.target)) box.open = false;
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && box.open) {
        box.open = false;
        var summary = box.querySelector('summary');
        if (summary) summary.focus();
      }
    });
  }

  /* ----------------------------------------------------------- 昵称搜索 */

  function initSearch() {
    var input = document.getElementById('site-search');
    var grid = document.getElementById('cards-grid');
    if (!input || !grid) return;

    var cards = Array.prototype.slice.call(grid.querySelectorAll('article[data-name]'));
    var empty = document.getElementById('cards-empty');
    var termSlot = empty && empty.querySelector('[data-search-term]');

    function apply() {
      var term = input.value.trim().toLowerCase();
      var shown = 0;
      cards.forEach(function (card) {
        var name = (card.getAttribute('data-name') || '').toLowerCase();
        var hit = !term || name.indexOf(term) !== -1;
        card.hidden = !hit;
        if (hit) shown += 1;
      });
      if (empty) empty.classList.toggle('hidden', shown !== 0);
      if (termSlot) termSlot.textContent = input.value.trim();
    }

    input.addEventListener('input', apply);
    input.addEventListener('search', apply);
    apply();
  }

  /* ------------------------------------------------------------ 排行榜 */

  // Number units differ per language (万/億 vs K/M/B), so the abbreviation
  // mirrors tools/build.py's format_count using the page's locale.
  function formatValue(value) {
    var app = document.getElementById('app');
    var locale = (app && app.dataset.locale) || 'zh-Hans';

    if (locale === 'en') {
      var units = [[1000000000, 'B'], [1000000, 'M'], [1000, 'K']];
      for (var i = 0; i < units.length; i += 1) {
        if (value >= units[i][0]) {
          return (value / units[i][0]).toFixed(1).replace(/\.0$/, '') + units[i][1];
        }
      }
      return value.toLocaleString('en-US');
    }

    var big = locale === 'ja' ? '億' : '亿';
    if (value >= 100000000) return (value / 100000000).toFixed(1).replace(/\.0$/, '') + big;
    if (value >= 10000) return (value / 10000).toFixed(1).replace(/\.0$/, '') + '万';
    return value.toLocaleString('zh-CN');
  }

  function initRanking() {
    var list = document.getElementById('ranking-list');
    if (!list) return;

    var rows = Array.prototype.slice.call(list.querySelectorAll('li[data-uid]'));
    if (!rows.length) return;

    var metricChips = Array.prototype.slice.call(document.querySelectorAll('.rank-chip[data-metric]'));
    var topChips = Array.prototype.slice.call(document.querySelectorAll('.rank-chip[data-top]'));
    var metric = 'fans';
    var top = 0;

    function valueOf(row) {
      return Number(row.getAttribute('data-' + metric)) || 0;
    }

    function render() {
      var ordered = rows.slice().sort(function (a, b) {
        return valueOf(b) - valueOf(a);
      });
      var max = valueOf(ordered[0]) || 1;

      ordered.forEach(function (row, index) {
        list.appendChild(row);
        var value = valueOf(row);
        row.hidden = index >= top && top > 0;
        row.querySelector('.rank-row__rank').textContent = String(index + 1);
        row.querySelector('.rank-row__value').textContent = formatValue(value);
        row.querySelector('.rank-row__bar > i').style.width =
          Math.max(2, Math.round((value / max) * 100)) + '%';
      });
    }

    metricChips.forEach(function (chip) {
      chip.addEventListener('click', function () {
        metric = chip.getAttribute('data-metric');
        metricChips.forEach(function (other) {
          other.classList.toggle('rank-chip--active', other === chip);
        });
        render();
      });
    });

    topChips.forEach(function (chip) {
      chip.addEventListener('click', function () {
        top = Number(chip.getAttribute('data-top')) || 0;
        topChips.forEach(function (other) {
          other.classList.toggle('rank-chip--active', other === chip);
        });
        render();
      });
    });

    render();
  }

  /* -------------------------------------------------------- 移动端导航 */

  function initMobileNav() {
    var nav = document.getElementById('mobile-nav');
    if (!nav) return;
    var left = document.querySelector('[data-nav-edge="left"]');
    var right = document.querySelector('[data-nav-edge="right"]');

    function paint() {
      var max = nav.scrollWidth - nav.clientWidth;
      if (left) left.hidden = nav.scrollLeft <= 4;
      if (right) right.hidden = max <= 4 || nav.scrollLeft >= max - 4;
    }

    nav.addEventListener('scroll', paint, { passive: true });
    window.addEventListener('resize', paint);
    paint();

    var active = nav.querySelector('.module-tab--active');
    if (active && active.scrollIntoView) {
      active.scrollIntoView({ inline: 'center', block: 'nearest' });
    }
  }

  /* ---------------------------------------------------------- 回到顶部 */

  function initBackToTop() {
    var button = document.getElementById('back-to-top');
    if (!button) return;

    function paint() {
      button.hidden = window.scrollY < 400;
    }

    window.addEventListener('scroll', paint, { passive: true });
    button.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    paint();
  }

  function boot() {
    window.__furupPageData = readPageData();
    initTheme();
    initLangSwitch();
    initSearch();
    initRanking();
    initMobileNav();
    initBackToTop();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();

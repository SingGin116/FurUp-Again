#!/usr/bin/env python3
"""Enrich the UP主 dump with play counts from the LetsFurry public API.

up-data.js only carries 粉丝(f) / 关注(g) / 简介(i) — there is no play count in
it.  The public ranking endpoint exposes `playCount` but has no pagination, so
the only way to widen coverage is to pull the top 100 for each of the three
metrics it supports and merge them by uid.

Writes data/playcount.json: { source, fetchedAt, count, plays: { uid: int } }
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import letsfurry_api as api  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
METRICS = ("followers", "likes", "playCount")


def main() -> int:
    plays: dict[str, int] = {}
    per_metric: dict[str, int] = {}

    for metric in METRICS:
        try:
            payload = api.get(
                "/public/furup/ranking",
                {"metric": metric, "limit": 100, "schema": "site-loadout-v1"},
            )
        except Exception as err:  # noqa: BLE001
            print(f"!! {metric}: {err}", file=sys.stderr)
            continue
        added = 0
        for item in payload.get("items", []):
            uid, count = item.get("uid"), item.get("playCount")
            if uid and isinstance(count, int) and count >= 0:
                if uid not in plays:
                    added += 1
                plays[uid] = count
        per_metric[metric] = added
        print(f"  {metric:<10} items={len(payload.get('items', [])):<4} new uids={added}")

    DATA.mkdir(parents=True, exist_ok=True)
    (DATA / "playcount.json").write_text(
        json.dumps(
            {
                "source": "api.letsfurry.com /public/furup/ranking",
                "fetchedAt": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "metrics": list(METRICS),
                "count": len(plays),
                "plays": plays,
            },
            ensure_ascii=False,
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )

    # how many of the creators we are going to display does this cover?
    # (read the dump directly: creators.json is written after this step)
    raw = (ROOT / "up-data.js").read_text(encoding="utf-8", errors="replace")
    dump = json.loads(raw[raw.find("[") : raw.rfind("]") + 1])
    top = [str(row.get("u")) for row in dump[:100]]
    covered = sum(1 for uid in top if uid in plays)
    print(f"\nplay counts : {len(plays)} uids")
    print(f"coverage    : {covered}/{len(top)} of the creators this site displays")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

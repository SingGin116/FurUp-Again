﻿#!/usr/bin/env python3
"""Pretty-print a fragment of a cleaned page or module file.

    python tools/peek.py <file> <xpath> [--limit N] [--text]
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from lxml import html as LH, etree

ROOT = Path(__file__).resolve().parent.parent.parent


def resolve(name: str) -> Path:
    for base in (ROOT, ROOT / "work" / "clean", ROOT / "work" / "modules"):
        for candidate in (base / name, base / f"{name}.html"):
            if candidate.is_file():
                return candidate
    raise SystemExit(f"not found: {name}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("xpath", nargs="?", default="//body")
    ap.add_argument("--limit", type=int, default=1)
    ap.add_argument("--text", action="store_true")
    args = ap.parse_args()

    path = resolve(args.file)
    doc = LH.fromstring(path.read_text(encoding="utf-8"))
    nodes = doc.xpath(args.xpath)
    if not isinstance(nodes, list):
        nodes = [nodes]
    print(f"# {path}  {args.xpath} -> {len(nodes)} match(es)")
    for i, node in enumerate(nodes[: args.limit]):
        if not hasattr(node, "tag"):
            print(f"[{i}] {node!r}")
        elif args.text:
            print(f"[{i}] " + re.sub(r"\s+", " ", node.text_content() or "").strip())
        else:
            print(f"--- [{i}]")
            print(etree.tostring(node, encoding="unicode", method="html", pretty_print=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Import the local up-data.js dump into the site's data model.

up-data.js is a single `var rawData = [...]` array of Bilibili UP主, one entry
per creator.  Field meanings (inferred from the archive's own 粉丝/获赞/播放
convention and the first-letter naming):

    r  rank      粉丝数排名
    u  uid       Bilibili mid
    n  name      昵称
    f  fans      粉丝数
    g  following 关注数
    a  avatar    头像 URL
    i  intro     个人签名

This writes:

    data/up.json         the full, normalised list (single source of truth)
    data/creators.json   the display subset (top N) in the card schema

Avatar URLs are kept as-is (hotlinked from Bilibili's CDN) — no download is
performed, so no copyright/bandwidth burden falls on this project.
"""

from __future__ import annotations

import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"

TOP_N = 100


def format_count(value: int) -> str:
    if value >= 100_000_000:
        return f"{value / 100_000_000:.1f}".rstrip("0").rstrip(".") + "亿"
    if value >= 10_000:
        return f"{value / 10_000:.1f}".rstrip("0").rstrip(".") + "万"
    return f"{value:,}"


def parse_updata() -> list[dict[str, Any]]:
    raw = (ROOT / "up-data.js").read_text(encoding="utf-8", errors="replace")
    start, end = raw.find("["), raw.rfind("]")
    if start < 0 or end < 0:
        raise SystemExit("up-data.js: no JSON array found")

    rows = json.loads(raw[start : end + 1])
    out = []
    for row in rows:
        uid = str(row.get("u") or "").strip()
        name = (row.get("n") or "").strip()
        if not uid or not name:
            continue
        out.append(
            {
                "uid": uid,
                "name": name,
                "avatar": (row.get("a") or "").strip(),
                "fans": int(row.get("f") or 0),
                "following": int(row.get("g") or 0),
                "intro": (row.get("i") or "").strip(),
                "rank": int(row.get("r") or 0),
            }
        )
    return out


def load_playcounts() -> dict[str, int]:
    """Play counts come from a separate enrichment step (see fetch_playcount.py).

    up-data.js has no play count, so this may legitimately be empty or partial.
    """
    path = DATA / "playcount.json"
    if not path.is_file():
        return {}
    payload = json.loads(path.read_text(encoding="utf-8"))
    return {str(uid): int(v) for uid, v in (payload.get("plays") or {}).items()}


def main() -> int:
    items = parse_updata()
    plays = load_playcounts()
    fetched = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    (DATA / "up.json").write_text(
        json.dumps(
            {
                "source": "up-data.js",
                "fetchedAt": fetched,
                "total": len(items),
                "fields": {
                    "fans": "f 粉丝数",
                    "following": "g 关注数",
                    "uid": "u Bilibili mid",
                    "name": "n 昵称",
                    "avatar": "a 头像",
                    "intro": "i 个人签名",
                    "rank": "r 粉丝排名",
                },
                "items": items,
            },
            ensure_ascii=False,
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )

    display = items[:TOP_N]
    cards = []
    covered = 0
    for item in display:
        value = plays.get(item["uid"])
        if value is not None:
            covered += 1
        cards.append(
            {
                "uid": item["uid"],
                "name": item["name"],
                "avatar": item["avatar"],
                "fans": item["fans"],
                "fansText": format_count(item["fans"]),
                "following": item["following"],
                "followingText": format_count(item["following"]),
                "plays": value,
                "playsText": format_count(value) if value is not None else None,
                "rank": item["rank"],
                "space": f"https://space.bilibili.com/{item['uid']}",
            }
        )
    (DATA / "creators.json").write_text(
        json.dumps(
            {
                "count": len(cards),
                "total": len(items),
                "source": "up-data.js",
                "fetchedAt": fetched,
                "playsSource": "data/playcount.json" if plays else None,
                "playsCoverage": covered,
                "items": cards,
            },
            ensure_ascii=False,
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )

    print(f"up.json      : {len(items):,} creators")
    print(f"creators.json: {len(cards):,} displayed (top {TOP_N})")
    print(f"play counts  : {covered}/{len(cards)} covered"
          + ("" if plays else " (data/playcount.json missing — run fetch_playcount.py)"))
    top = cards[0]
    print(f"top creator  : {top['name']}  fans={top['fansText']} following={top['followingText']} "
          f"plays={top['playsText'] or '—'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
